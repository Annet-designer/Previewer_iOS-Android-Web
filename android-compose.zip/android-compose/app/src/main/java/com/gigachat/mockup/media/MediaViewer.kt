package com.gigachat.mockup.media

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.gigachat.mockup.R
import com.gigachat.mockup.chat.GestureBar
import com.gigachat.mockup.model.MediaItem
import com.gigachat.mockup.overlay.BlobMenu
import com.gigachat.mockup.overlay.MenuEntry
import com.gigachat.mockup.ui.theme.Token
import kotlinx.coroutines.delay
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Просмотрщик фото и видео.
 *
 * Слои снизу вверх: кадр, вуали, кнопка воспроизведения, подпись,
 * шапка и нижний блок. Порядок важен — поднятая подпись должна идти
 * поверх кнопки, но под шапкой.
 */
@Composable
fun MediaViewer(
    items: List<MediaItem>,
    startIndex: Int,
    caption: String?,
    onClose: () -> Unit,
    onCollapse: (MediaItem) -> Unit
) {
    var index by remember { mutableIntStateOf(startIndex) }
    val item = items[index]

    var chromeVisible by remember { mutableStateOf(true) }
    var counterVisible by remember { mutableStateOf(false) }
    var menuShown by remember { mutableStateOf(false) }

    val clock = rememberPlaybackClock(item.duration)
    val captionScroll = rememberScrollState()
    val captionRaised by remember { derivedStateOf { captionScroll.value > 0 } }

    // ---- Автоскрытие обвязки ----
    //
    // Не срабатывает, пока открыто меню или поднята подпись: иначе
    // обвязка уезжает посреди жеста и текст невозможно поднять.
    var hideRequest by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(hideRequest, menuShown, captionRaised) {
        val delayMs = hideRequest ?: return@LaunchedEffect
        delay(delayMs)
        if (clock.isPlaying && !menuShown && !captionRaised) chromeVisible = false
    }

    fun showChrome() { hideRequest = null; chromeVisible = true }
    fun armHide(ms: Long) { hideRequest = ms }

    LaunchedEffect(index) {
        clock.reset(item.duration)
        showChrome()
        counterVisible = items.size > 1
        delay(Token.Motion.COUNTER_FRAMES)
        counterVisible = false
    }

    val chromeAlpha by animateFloatAsState(
        targetValue = if (chromeVisible) 1f else 0f,
        animationSpec = if (chromeVisible) Token.Motion.ChromeIn else Token.Motion.ChromeOut,
        label = "chrome"
    )

    Box(Modifier.fillMaxSize().background(Token.BackdropDark)) {

        Frame(
            item = item,
            dim = min(0.65f, captionScroll.value / 500f * 0.65f),
            onTap = {
                if (item.isVideo) {
                    if (!chromeVisible) {
                        showChrome()
                        if (clock.isPlaying) armHide(Token.Motion.HIDE_AFTER_TAP)
                    }
                } else {
                    // У фото тап работает переключателем: можно смотреть
                    // снимок без обвязки и вернуть её тем же жестом.
                    if (chromeVisible && !captionRaised) chromeVisible = false else showChrome()
                }
            }
        )

        Veils(Modifier.alpha(chromeAlpha))

        if (item.isVideo) {
            PlayButton(
                isPlaying = clock.isPlaying,
                modifier = Modifier.align(Alignment.Center).alpha(chromeAlpha),
                onClick = {
                    clock.toggle()
                    if (clock.isPlaying) armHide(Token.Motion.HIDE_AFTER_PLAY) else showChrome()
                }
            )
        }

        if (caption != null) {
            CaptionScroll(
                text = caption,
                scrollState = captionScroll,
                modifier = Modifier.alpha(chromeAlpha),
                onTouch = { showChrome() },
                onRelease = { if (clock.isPlaying && !captionRaised) armHide(Token.Motion.HIDE_AFTER_TAP) }
            )
        }

        // ---- Шапка ----
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .offset { IntOffset(0, ((1f - chromeAlpha) * -116.dp.toPx()).roundToInt()) }
                .alpha(chromeAlpha)
                .background(Token.BackdropDark.copy(alpha = 0f))
        ) {
            Spacer(Modifier.height(Token.Layout.StatusBar))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().height(Token.Layout.AppBar).padding(horizontal = 4.dp)
            ) {
                IconButton(R.drawable.icon_back, Token.AccentIcon, onClose)
                Spacer(Modifier.width(4.dp))
                Column(Modifier.weight(1f)) {
                    Text("Иван Петров", style = Token.Type.Title, color = Color.White)
                    Text("Сегодня, 9:41", style = Token.Type.Footnote,
                        color = Color.White.copy(alpha = 0.62f))
                }
                if (item.isVideo) IconButton(R.drawable.action_settings, Token.AccentIcon) {}
                IconButton(R.drawable.action_forward, Token.AccentIcon) {}
                IconButton(R.drawable.icon_more, Token.AccentIcon) { menuShown = true }
            }
        }

        // ---- Счётчик кадров ----
        if (items.size > 1) {
            Text(
                "${index + 1} из ${items.size}",
                style = Token.Type.Footnote,
                color = Token.Ink,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = Token.Layout.TopBar)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.7f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .alpha(if (counterVisible) chromeAlpha else 0f)
            )
        }

        // ---- Низ: лента, плеер, полоска жестов ----
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .offset { IntOffset(0, ((1f - chromeAlpha) * 140.dp.toPx()).roundToInt()) }
                .alpha(chromeAlpha)
        ) {
            ThumbnailStrip(items, index) { index = it }
            Spacer(Modifier.height(16.dp))
            if (item.isVideo) PlayerBar(clock)
            Spacer(Modifier.height(8.dp))
            GestureBar(light = true)
        }

        if (menuShown) {
            BlobMenu(
                dark = true,
                entries = listOf(
                    MenuEntry("Поделиться", R.drawable.menu_share),
                    MenuEntry("Показать в чате", R.drawable.menu_eye),
                    MenuEntry("Ответить", R.drawable.menu_reply),
                    MenuEntry("Свернуть", R.drawable.menu_collapse,
                        enabled = item.isVideo, onClick = { onCollapse(item) }),
                    MenuEntry("Удалить", R.drawable.menu_trash, destructive = true)
                ),
                onDismiss = { menuShown = false },
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 110.dp, end = 12.dp)
            )
        }
    }
}

/**
 * Кадр во всю высоту экрана.
 *
 * Размер считается арифметикой, а не через `aspectRatio` с ограничением
 * по высоте: та связка режет высоту и молча обрезает длинные
 * вертикальные снимки.
 */
@Composable
private fun Frame(item: MediaItem, dim: Float, onTap: () -> Unit) {
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .pointerInput(item) { detectTapGestures { onTap() } },
        contentAlignment = Alignment.Center
    ) {
        val width = min(maxWidth.value, maxHeight.value * item.aspect).dp
        val height = width / item.aspect
        Box {
            Image(
                painter = painterResource(item.asset),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(width, height)
            )
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = dim)))
        }
    }
}

@Composable
private fun Veils(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().height(180.dp).background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = 0.62f),
                    0.34f to Color.Black.copy(alpha = 0.44f),
                    1f to Color.Transparent
                )
            )
        )
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.fillMaxWidth().height(260.dp).background(
                Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.42f to Color.Black.copy(alpha = 0.38f),
                    1f to Color.Black.copy(alpha = 0.82f)
                )
            )
        )
    }
}

@Composable
private fun PlayButton(isPlaying: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.32f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painterResource(if (isPlaying) R.drawable.icon_pause else R.drawable.icon_play_badge),
            contentDescription = null,
            modifier = Modifier.size(26.dp),
            tint = Color.White
        )
    }
}

@Composable
private fun IconButton(icon: Int, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(icon), null, Modifier.size(24.dp), tint)
    }
}
