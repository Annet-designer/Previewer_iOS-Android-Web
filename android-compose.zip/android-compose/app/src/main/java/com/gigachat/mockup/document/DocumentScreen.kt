package com.gigachat.mockup.document

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gigachat.mockup.R
import com.gigachat.mockup.chat.GestureBar
import com.gigachat.mockup.model.DocumentFile
import com.gigachat.mockup.overlay.BlobMenu
import com.gigachat.mockup.overlay.MenuEntry
import com.gigachat.mockup.ui.theme.Token
import kotlinx.coroutines.delay

/**
 * Превьюер документа — полноэкранная страница, а не bottom sheet.
 * Скруглений, тени и хвата сверху нет.
 */
@Composable
fun DocumentScreen(file: DocumentFile, onClose: () -> Unit) {
    val listState = rememberLazyListState()
    var menuShown by remember { mutableStateOf(false) }
    var counterVisible by remember { mutableStateOf(false) }

    // Схлопывание обвязки на первых 100 точках прокрутки.
    val chromeAlpha by remember {
        derivedStateOf {
            val offset = if (listState.firstVisibleItemIndex > 0) 100f
            else listState.firstVisibleItemScrollOffset / 3f
            (1f - offset / 100f).coerceIn(0f, 1f)
        }
    }

    // Номер страницы — по фактическому индексу видимого листа:
    // у слайдов, таблиц и A4 разная высота, фиксированный шаг не годится.
    val currentPage by remember { derivedStateOf { listState.firstVisibleItemIndex + 1 } }

    LaunchedEffect(currentPage, listState.isScrollInProgress) {
        if (listState.isScrollInProgress) {
            counterVisible = true
        } else {
            delay(Token.Motion.COUNTER_PAGES)
            counterVisible = false
        }
    }

    Box(Modifier.fillMaxSize().background(Token.Paper)) {

        LazyColumn(
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(top = 124.dp, bottom = 44.dp),
            modifier = Modifier.fillMaxSize().background(Token.SurfaceCard)
        ) {
            items(file.kind.pageCount) { page ->
                DocumentPage(file.kind, page + 1)
            }
        }

        // ---- Шапка: белая и непрозрачная ----
        Column(
            Modifier
                .fillMaxWidth()
                .background(Token.Paper)
                .alpha(chromeAlpha)
        ) {
            Spacer(Modifier.height(Token.Layout.StatusBar))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().height(Token.Layout.AppBar).padding(horizontal = 4.dp)
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = onClose
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(painterResource(R.drawable.icon_back), null, Modifier.size(24.dp), Token.AccentDark)
                }
                Text(
                    file.name,
                    style = Token.Type.Title,
                    color = Token.Ink,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    Modifier
                        .size(48.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { menuShown = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(painterResource(R.drawable.icon_more), null, Modifier.size(24.dp), Token.AccentDark)
                }
            }
        }

        // ---- Счётчик страниц ----
        if (file.kind.pageCount > 1) {
            Text(
                "$currentPage из ${file.kind.pageCount}",
                style = Token.Type.Footnote,
                color = Token.Ink,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 16.dp, top = 132.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.7f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .alpha(if (counterVisible) 1f else 0f)
            )
        }

        GestureBar(modifier = Modifier.align(Alignment.BottomCenter))

        if (menuShown) {
            BlobMenu(
                dark = false,
                entries = listOf(
                    MenuEntry("Показать в чате", R.drawable.menu_eye),
                    MenuEntry("Ответить", R.drawable.menu_reply),
                    MenuEntry("Переслать", R.drawable.menu_forward),
                    MenuEntry("Поделиться", R.drawable.menu_share),
                    MenuEntry("Печать", R.drawable.menu_print)
                ),
                onDismiss = { menuShown = false },
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 110.dp, end = 12.dp)
            )
        }
    }
}

/** Перегрузка: полоска жестов с внешним модификатором. */
@Composable
private fun GestureBar(modifier: Modifier) {
    Box(modifier.fillMaxWidth()) { GestureBar() }
}
