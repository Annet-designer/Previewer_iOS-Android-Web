package com.gigachat.mockup.document

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gigachat.mockup.model.DocumentFile
import com.gigachat.mockup.ui.theme.Token

/**
 * Отрисовка страницы по типу файла.
 *
 * В мокапе содержимое было свёрстано целиком — семь наборов вручную.
 * Здесь оставлена структура и по одному характерному блоку на тип: в
 * проекте сюда встанет реальный рендер (PdfRenderer, WebView), а
 * разметка нужна, чтобы видеть раскладку и отступы.
 */
@Composable
fun DocumentPage(kind: DocumentFile.Kind, number: Int) {
    when (kind) {
        DocumentFile.Kind.DOCX, DocumentFile.Kind.PDF -> Paper(kind, number)
        DocumentFile.Kind.PPTX -> Slide(number)
        DocumentFile.Kind.XLSX -> Sheet(number)
        DocumentFile.Kind.HTML -> Web(number)
        DocumentFile.Kind.MD, DocumentFile.Kind.TXT -> Plain()
    }
}

@Composable
private fun Paper(kind: DocumentFile.Kind, number: Int) {
    Column(
        Modifier
            .fillMaxWidth()
            .height(572.dp)
            .background(Token.Paper)
            .padding(horizontal = 38.3.dp, vertical = 37.3.dp)
    ) {
        if (number == 1) {
            Text(
                if (kind == DocumentFile.Kind.PDF) "Гайдлайн бренда" else "Дизайн-концепция сайта",
                fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Token.Ink
            )
            Spacer(Modifier.height(6.dp))
            Text("Версия 2.4 · отдел дизайна · сентябрь 2026",
                fontSize = 7.sp, color = Token.InkSecondary)
            Spacer(Modifier.height(12.dp))
        }
        repeat(6) {
            Text("Текст страницы. ".repeat(12), fontSize = 7.sp, color = Token.Ink)
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun Slide(number: Int) {
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .height(214.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Token.Paper)
            .padding(16.dp)
    ) {
        Text("Слайд $number", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Token.Ink)
        Spacer(Modifier.height(6.dp))
        Text("Подзаголовок раздела", fontSize = 8.sp, color = Token.InkSecondary)
    }
}

@Composable
private fun Sheet(number: Int) {
    Column(Modifier.fillMaxWidth().background(Token.Paper).padding(8.dp)) {
        Text(
            if (number == 1) "Трафик по разделам" else "Конверсии по источникам",
            fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Token.Ink
        )
        Spacer(Modifier.height(8.dp))
        repeat(10) { row ->
            Row(Modifier.fillMaxWidth()) {
                repeat(5) { column ->
                    Text(
                        if (row == 0) "Колонка ${column + 1}" else "—",
                        fontSize = 7.sp,
                        color = Token.Ink,
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (row == 0) Token.Accent.copy(alpha = 0.12f) else Token.Paper
                            )
                            .padding(4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun Web(number: Int) {
    Column(
        Modifier.fillMaxWidth().height(420.dp).background(Token.Paper).padding(18.dp)
    ) {
        Text(
            if (number == 1) "Рендер страницы" else "Исходный код",
            fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Token.Ink
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (number == 1) "Здесь показывается сайт целиком."
            else "<!DOCTYPE html>\n<html lang=\"ru\">\n  <head>…</head>\n</html>",
            fontSize = 7.sp,
            fontFamily = if (number == 1) FontFamily.Default else FontFamily.Monospace,
            color = Token.InkSecondary
        )
    }
}

@Composable
private fun Plain() {
    Text(
        "заметки со встречи по редизайну\n".repeat(20),
        fontSize = 7.sp,
        fontFamily = FontFamily.Monospace,
        color = Token.Ink,
        modifier = Modifier
            .fillMaxWidth()
            .background(Token.Paper)
            .padding(horizontal = 18.dp, vertical = 16.dp)
    )
}
