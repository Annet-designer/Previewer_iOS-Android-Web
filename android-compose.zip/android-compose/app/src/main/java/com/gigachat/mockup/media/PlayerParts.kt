package com.gigachat.mockup.media

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.gigachat.mockup.model.MediaItem
import com.gigachat.mockup.ui.theme.Token
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---- Часы воспроизведения ----

/**
 * Имитация плеера. В проекте на её место встаёт ExoPlayer — интерфейс
 * тот же: progress, isPlaying, toggle().
 */
@Stable
class PlaybackClock(initialDuration: Int) {
    var duration by mutableIntStateOf(initialDuration)
        private set
    var time by mutableFloatStateOf(0f)
        private set
    var isPlaying by mutableStateOf(false)
        private set

    val progress: Float get() = if (duration > 0) time / duration else 0f

    fun toggle() { isPlaying = !isPlaying }

    fun tick(deltaSeconds: Float) {
        if (!isPlaying) return
        time += deltaSeconds
        if (time >= duration) time = 0f   // ролик идёт по кругу
    }

    fun reset(newDuration: Int) {
        isPlaying = false
        duration = newDuration
        time = 0f
    }

    fun seekTo(fraction: Float) {
        time = max(0f, min(duration.toFloat(), duration * fraction))
    }

    fun seekBy(seconds: Int) {
        time = max(0f, min(duration.toFloat(), time + seconds))
    }

    companion object {
        fun format(seconds: Float): String {
            val s = seconds.roundToInt()
            return "%d:%02d".format(s / 60, s % 60)
        }
    }
}

@Composable
fun rememberPlaybackClock(duration: Int): PlaybackClock {
    val clock = remember { PlaybackClock(duration) }
    LaunchedEffect(clock.isPlaying) {
        while (clock.isPlaying) {
            delay(100)
            clock.tick(0.1f)
        }
    }
    return clock
}

// ---- Полоса плеера ----

/**
 * Полоса от края до края с внутренними полями 24. Фон задан
 * прозрачностью 0.82 — той же, что у нижней вуали, поэтому полоса
 * сливается с фоном вокруг и шва не видно.
 */
@Composable
fun PlayerBar(clock: PlaybackClock, compact: Boolean = false) {
    val height by animateDpAsState(if (compact) 6.dp else 44.dp, label = "player")

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .height(height)
            .then(if (compact) Modifier else Modifier.background(Color.Black.copy(alpha = 0.82f)))
            .padding(horizontal = 24.dp)
    ) {
        if (!compact) {
            Text(PlaybackClock.format(clock.time), style = Token.Type.Footnote, color = Color.White)
            Spacer(Modifier.width(10.dp))
        }
        Track(clock, Modifier.weight(1f))
        if (!compact) {
            Spacer(Modifier.width(10.dp))
            Text(PlaybackClock.format(clock.duration.toFloat()),
                style = Token.Type.Footnote, color = Color.White)
        }
    }
}

@Composable
private fun Track(clock: PlaybackClock, modifier: Modifier = Modifier) {
    BoxWithConstraints(
        modifier
            .height(6.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color.White.copy(alpha = 0.24f))
            .pointerInput(Unit) {
                detectHorizontalTap { fraction -> clock.seekTo(fraction) }
            }
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .width(maxWidth * clock.progress)
                .clip(RoundedCornerShape(6.dp))
                .background(Color.White)
        )
    }
}

private suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectHorizontalTap(
    onTap: (Float) -> Unit
) {
    androidx.compose.foundation.gestures.detectTapGestures { offset ->
        onTap((offset.x / size.width).coerceIn(0f, 1f))
    }
}

// ---- Лента миниатюр ----

/**
 * Механика как в Telegram: невыбранные кадры узкие, выбранный
 * раскрывается по своим пропорциям. Вся лента умещается в кадр с
 * полями 24 — прокрутки нет. Если широкий выбранный не влезает,
 * остальные ужимаются, нижний предел 10.
 */
@Composable
fun ThumbnailStrip(items: List<MediaItem>, selected: Int, onSelect: (Int) -> Unit) {
    val height = 36.dp
    val gap = 4.dp
    val frameInset = 24.dp
    val narrowDefault = 20.dp

    BoxWithConstraints(
        Modifier.fillMaxWidth().padding(horizontal = frameInset),
        contentAlignment = Alignment.Center
    ) {
        val activeWidth = (height.value * items[selected].aspect).dp
        val fit = if (items.size > 1) {
            ((maxWidth - gap * (items.size - 1) - activeWidth) / (items.size - 1))
        } else narrowDefault
        val narrow = max(10f, min(narrowDefault.value, fit.value)).dp

        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
            items.forEachIndexed { index, item ->
                val width by animateDpAsState(
                    if (index == selected) activeWidth else narrow,
                    label = "thumb"
                )
                Box(
                    Modifier
                        .size(width, height)
                        .clip(RoundedCornerShape(Token.Radius.Thumb))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(index) }
                ) {
                    Image(
                        painter = painterResource(item.asset),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (index != selected) {
                        Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.4f)))
                    }
                }
            }
        }
    }
}

// ---- Подпись ----

/**
 * Подпись прижата к низу распоркой и разворачивается прокруткой вверх.
 *
 * Слой прозрачен для нажатий, ловит только сам текст: иначе распорка
 * накрывает кнопку воспроизведения и по видео нельзя попасть.
 */
@Composable
fun CaptionScroll(
    text: String,
    scrollState: androidx.compose.foundation.ScrollState,
    modifier: Modifier = Modifier,
    onTouch: () -> Unit,
    onRelease: () -> Unit
) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        Column(
            Modifier
                .verticalScroll(scrollState)
                .pointerInput(Unit) {
                    androidx.compose.foundation.gestures.detectDragGestures(
                        onDragStart = { onTouch() },
                        onDragEnd = { onRelease() }
                    ) { _, _ -> }
                }
        ) {
            // Распорка задаёт, сколько текста видно в покое.
            Spacer(Modifier.height(max(0f, maxHeight.value - 190f).dp))
            Text(
                text,
                style = Token.Type.Body,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)
            )
        }
    }
}
