package com.gigachat.mockup.overlay

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.gigachat.mockup.R
import com.gigachat.mockup.media.PlaybackClock
import com.gigachat.mockup.model.MediaItem
import com.gigachat.mockup.ui.theme.Token
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Мини-экран поверх чата.
 *
 * В продакшене видео в PiP отдаётся системе и окно рисует Android.
 * Здесь окно своё: живёт внутри приложения, зато полностью управляемо.
 */
@Composable
fun PipWindow(
    item: MediaItem,
    clock: PlaybackClock,
    onExpand: () -> Unit,
    onClose: () -> Unit
) {
    val edgeX = 10.dp
    val edgeTop = 56.dp
    val edgeBottom = 40.dp
    val baseWidth = 225.dp

    var controlsVisible by remember { mutableStateOf(true) }
    var poke by remember { mutableIntStateOf(0) }
    LaunchedEffect(poke) {
        controlsVisible = true
        delay(Token.Motion.PIP_CONTROLS)
        controlsVisible = false
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val width = min(
            (maxWidth - edgeX * 2).value,
            max(baseWidth.value, baseWidth.value * item.aspect)
        ).dp
        val height = width / item.aspect

        val minX = with(density) { edgeX.toPx() }
        val minY = with(density) { edgeTop.toPx() }
        val maxX = with(density) { (maxWidth - width - edgeX).toPx() }
        val maxY = with(density) { (maxHeight - height - edgeBottom).toPx() }
        val boundsWidth = with(density) { maxWidth.toPx() }
        val boundsHeight = with(density) { maxHeight.toPx() }
        val windowWidth = with(density) { width.toPx() }
        val windowHeight = with(density) { height.toPx() }

        val offsetX = remember { Animatable(maxX) }
        val offsetY = remember { Animatable(with(density) { 128.dp.toPx() }) }
        val scope = rememberCoroutineScope()
        var moved by remember { mutableStateOf(false) }

        Box(
            Modifier
                .offset { IntOffset(offsetX.value.roundToInt(), offsetY.value.roundToInt()) }
                .size(width, height)
                .shadow(16.dp, RoundedCornerShape(Token.Radius.Pip))
                .clip(RoundedCornerShape(Token.Radius.Pip))
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { moved = false; poke++ },
                        onDragEnd = {
                            // Примагничивание к ближайшему из четырёх углов:
                            // смотрим, в какой половине экрана центр окна.
                            val targetX =
                                if (offsetX.value + windowWidth / 2 < boundsWidth / 2) minX else maxX
                            val targetY =
                                if (offsetY.value + windowHeight / 2 < boundsHeight / 2) minY else maxY
                            scope.launch { offsetX.animateTo(targetX, Token.Motion.PipSnap) }
                            scope.launch { offsetY.animateTo(targetY, Token.Motion.PipSnap) }
                        }
                    ) { change, drag ->
                        change.consume()
                        moved = true
                        scope.launch {
                            offsetX.snapTo((offsetX.value + drag.x).coerceIn(minX, maxX))
                            offsetY.snapTo((offsetY.value + drag.y).coerceIn(minY, maxY))
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures {
                        // При скрытых кнопках первый тап возвращает их,
                        // а не разворачивает окно.
                        if (controlsVisible && !moved) onExpand() else poke++
                    }
                }
        ) {
            Image(
                painter = painterResource(item.asset),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            PipButton(R.drawable.action_close, Modifier.align(Alignment.TopStart).padding(6.dp),
                controlsVisible, onClose)
            PipButton(R.drawable.action_expand, Modifier.align(Alignment.TopEnd).padding(6.dp),
                controlsVisible, onExpand)

            if (item.isVideo) {
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .size(46.dp)
                        .alpha(if (controlsVisible) 1f else 0f)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.44f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { clock.toggle(); poke++ },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painterResource(
                            if (clock.isPlaying) R.drawable.icon_pause else R.drawable.icon_play_badge
                        ),
                        null, Modifier.size(23.dp), Color.White
                    )
                }

                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(8.dp)
                        .fillMaxWidth()
                        .height(4.dp)
                        .alpha(if (controlsVisible) 1f else 0f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White.copy(alpha = 0.3f))
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(clock.progress)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.White)
                    )
                }
            }
        }
    }
}

@Composable
private fun PipButton(icon: Int, modifier: Modifier, visible: Boolean, onClick: () -> Unit) {
    Box(
        modifier
            .size(28.dp)
            .alpha(if (visible) 1f else 0f)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.44f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(icon), null, Modifier.size(13.dp), Color.White)
    }
}
