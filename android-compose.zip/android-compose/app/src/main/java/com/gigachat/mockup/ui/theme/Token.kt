package com.gigachat.mockup.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Токены из Pixso-экспорта. Значения совпадают с `tokens/tokens.css`
 * в паке для разработки.
 */
object Token {

    // ---- Палитра ----
    val Accent      = Color(0xFF0BA686)
    val AccentDark  = Color(0xFF0A8E73)
    val AccentDeep  = Color(0xFF09856B)
    /** Иконки в шапке просмотрщика медиа. */
    val AccentIcon  = Color(0xFF61C8B0)

    val Ink          = Color(0xFF15110F)
    val InkSecondary = Color(0xA315110F)   // 64%
    val InkTertiary  = Color(0x3D15110F)   // 24%

    val Surface     = Color(0xFFF0F0F0)
    val SurfaceCard = Color(0xFFF5F5F5)
    val Paper       = Color(0xFFFFFFFF)
    val BackdropDark = Color(0xFF141413)

    /** Статус-бар Material. */
    val OnSurfaceM3 = Color(0xFF1D1B20)
    val NavPill     = Color(0xFF282422)

    /** «Удалить» в меню: светлая и тёмная темы. */
    val Negative     = Color(0xFFD11D23)
    val NegativeDark = Color(0xFFF57E83)

    val OverlayMedium = Color(0x52000000)  // 32%

    /** Заливка исходящего пузыря. */
    val OutgoingBubble = Brush.linearGradient(
        colors = listOf(Accent, AccentDeep),
        start = Offset.Zero,
        end = Offset(Float.POSITIVE_INFINITY, 0f)
    )

    // ---- Скругления ----
    object Radius {
        val Screen = 44.dp
        val Bubble = 16.dp
        /** Угол со стороны хвостика. */
        val BubbleCorner = 4.dp
        val Media = 15.dp
        val File = 12.dp
        val Menu = 16.dp
        val Pip = 14.dp
        val Thumb = 5.dp
        val Pill = 1000.dp
    }

    val BubbleIn  = RoundedCornerShape(Radius.Bubble, Radius.Bubble, Radius.Bubble, Radius.BubbleCorner)
    val BubbleOut = RoundedCornerShape(Radius.Bubble, Radius.Bubble, Radius.BubbleCorner, Radius.Bubble)

    // ---- Геометрия ----
    object Layout {
        val ScreenWidth = 412.dp
        val ScreenHeight = 892.dp
        val StatusBar = 52.dp
        val AppBar = 64.dp
        /** Статус-бар плюс аппбар. */
        val TopBar = 116.dp
        val NavBar = 24.dp
        val FeedTop = 120.dp
        val FeedBottom = 136.dp
    }

    // ---- Типографика ----
    //
    // Roboto подключается системой. Трекинг вручную не задаём: у Roboto
    // он уже подобран под каждый размер, ручная поправка расшатает текст
    // относительно системных контролов.
    object Type {
        val Body      = TextStyle(fontSize = 16.sp, lineHeight = 19.sp)
        val BodyMedium = TextStyle(fontSize = 16.sp, lineHeight = 19.sp, fontWeight = FontWeight.Medium)
        val Subhead   = TextStyle(fontSize = 15.sp, lineHeight = 18.sp)
        val Footnote  = TextStyle(fontSize = 13.sp, lineHeight = 15.sp)
        val Caption   = TextStyle(fontSize = 12.sp, lineHeight = 14.sp)
        val StatusBar = TextStyle(fontSize = 14.sp, lineHeight = 20.sp)
        /** Заголовок страницы: имя файла и имя собеседника в просмотрщике. */
        val Title     = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Medium)
        val MenuItem  = TextStyle(fontSize = 16.sp, lineHeight = 19.sp)
    }

    // ---- Движение ----
    //
    // Кривые подобраны так, чтобы появление начиналось быстро,
    // а уход — мягко разгонялся к краю экрана.
    object Motion {
        val ChromeIn  = tween<Float>(340, easing = CubicBezierEasing(0.32f, 0.72f, 0f, 1f))
        val ChromeOut = tween<Float>(300, easing = CubicBezierEasing(0.5f, 0f, 0.75f, 0f))
        val MenuPop   = tween<Float>(340, easing = CubicBezierEasing(0.25f, 0.9f, 0.3f, 1f))
        val MenuHide  = tween<Float>(170, easing = CubicBezierEasing(0.4f, 0f, 1f, 1f))
        val Thumb     = tween<Float>(280, easing = CubicBezierEasing(0.2f, 0.7f, 0.3f, 1f))
        val PipSnap   = spring<Float>(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow)

        const val HIDE_AFTER_PLAY = 1000L
        const val HIDE_AFTER_TAP  = 3000L
        const val COUNTER_FRAMES  = 2000L
        const val COUNTER_PAGES   = 1000L
        const val PIP_CONTROLS    = 2000L
    }
}
