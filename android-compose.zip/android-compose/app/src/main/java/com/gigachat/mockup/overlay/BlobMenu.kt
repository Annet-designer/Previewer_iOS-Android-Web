package com.gigachat.mockup.overlay

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.gigachat.mockup.ui.theme.Token

data class MenuEntry(
    val title: String,
    val icon: Int,
    val enabled: Boolean = true,
    val destructive: Boolean = false,
    val onClick: () -> Unit = {}
)

/**
 * Контекстное меню, вырастающее каплей.
 *
 * В мокапе анимировались ширина, высота и радиус: кружок 34×34
 * раздувался до полного размера. Здесь то же достигается
 * масштабированием с якорем в правом верхнем углу — дешевле по
 * отрисовке и не требует пересчёта раскладки каждый кадр.
 *
 * Экран под меню не затемняется: подложка прозрачная и нужна только
 * чтобы поймать нажатие мимо.
 */
@Composable
fun BlobMenu(
    dark: Boolean,
    entries: List<MenuEntry>,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }

    val scale by animateFloatAsState(
        targetValue = if (shown) 1f else 0.14f,
        animationSpec = Token.Motion.MenuPop,
        label = "menuScale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = Token.Motion.MenuPop,
        label = "menuAlpha"
    )

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
        )
        Column(
            modifier
                .width(273.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    this.alpha = alpha
                    transformOrigin = TransformOrigin(1f, 0f)
                }
                .shadow(12.dp, RoundedCornerShape(Token.Radius.Menu))
                .clip(RoundedCornerShape(Token.Radius.Menu))
                .background(if (dark) Color(0xFF232323) else Token.Paper)
        ) {
            entries.forEach { entry ->
                val tint = when {
                    entry.destructive && dark -> Token.NegativeDark
                    entry.destructive -> Token.Negative
                    dark -> Color.White
                    else -> Token.Ink
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clickable(enabled = entry.enabled) { entry.onClick(); onDismiss() }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .alpha(if (entry.enabled) 1f else 0.4f)
                ) {
                    Icon(painterResource(entry.icon), null, Modifier.size(24.dp), tint)
                    Spacer(Modifier.width(12.dp))
                    Text(entry.title, style = Token.Type.MenuItem, color = tint)
                }
            }
        }
    }
}
