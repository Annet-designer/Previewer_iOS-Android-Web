package com.gigachat.mockup

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.gigachat.mockup.chat.ChatScreen
import com.gigachat.mockup.document.DocumentScreen
import com.gigachat.mockup.media.MediaViewer
import com.gigachat.mockup.model.DocumentFile
import com.gigachat.mockup.model.MediaItem
import com.gigachat.mockup.overlay.PipWindow
import com.gigachat.mockup.media.rememberPlaybackClock
import com.gigachat.mockup.ui.theme.Token

/** Что показано поверх чата. */
private sealed interface Route {
    data object Chat : Route
    data class Document(val file: DocumentFile) : Route
    data class Viewer(val items: List<MediaItem>, val index: Int, val caption: String?) : Route
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = Token.Surface) {
                    Root()
                }
            }
        }
    }
}

@Composable
private fun Root() {
    var route by remember { mutableStateOf<Route>(Route.Chat) }
    var pipItem by remember { mutableStateOf<MediaItem?>(null) }
    val pipClock = rememberPlaybackClock(pipItem?.duration ?: 42)

    when (val current = route) {
        is Route.Chat -> ChatScreen(
            onOpenFile = { route = Route.Document(it) },
            onOpenMedia = { items, index, caption -> route = Route.Viewer(items, index, caption) }
        )

        is Route.Document -> DocumentScreen(current.file) { route = Route.Chat }

        is Route.Viewer -> MediaViewer(
            items = current.items,
            startIndex = current.index,
            caption = current.caption,
            onClose = { route = Route.Chat },
            onCollapse = { item ->
                // Воспроизведение при сворачивании не прерывается.
                pipItem = item
                route = Route.Chat
            }
        )
    }

    pipItem?.let { item ->
        PipWindow(
            item = item,
            clock = pipClock,
            onExpand = {
                pipItem = null
                route = Route.Viewer(listOf(item), 0, null)
            },
            onClose = { pipItem = null }
        )
    }
}
