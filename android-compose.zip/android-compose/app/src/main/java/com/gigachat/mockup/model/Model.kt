package com.gigachat.mockup.model

import androidx.annotation.DrawableRes
import com.gigachat.mockup.R

/** Кадр в галерее. */
data class MediaItem(
    @DrawableRes val asset: Int,
    /** Пропорции: ширина делить на высоту. В мокапе жили в `data-ar`. */
    val aspect: Float,
    val isVideo: Boolean = false,
    /** Хронометраж в секундах. Управляет плеером и наличием перемотки. */
    val duration: Int = 42
)

/** Документ, открываемый в превьюере. */
data class DocumentFile(
    val name: String,
    val kind: Kind,
    val size: String
) {
    enum class Kind(val badge: String, val pageCount: Int) {
        DOCX("docx", 3),
        PDF("pdf", 5),
        PPTX("pptx", 4),
        XLSX("xlsx", 2),
        HTML("html", 2),
        MD("md", 1),
        TXT("txt", 1)
    }
}

enum class GalleryLayout { GRID2, MOSAIC, SINGLE }

/** Сообщение в ленте. */
sealed interface MessageContent {
    data class Text(val value: String) : MessageContent
    data class Files(val files: List<DocumentFile>) : MessageContent
    data class Gallery(
        val items: List<MediaItem>,
        val layout: GalleryLayout,
        val caption: String? = null
    ) : MessageContent
}

data class Message(
    val id: Int,
    val isOutgoing: Boolean,
    val time: String,
    val content: MessageContent,
    /** Ширина пузыря из макета, null — по содержимому. */
    val width: Int? = null
)

/** Разделитель даты. */
data class DateDivider(val label: String)

/**
 * Содержимое чата один в один с мокапом — чтобы экран можно было
 * сверять с макетом, не подставляя свои данные.
 */
object SampleData {

    val files = listOf(
        DocumentFile("Дизайн-концепция_сайта.docx", DocumentFile.Kind.DOCX, "48 Кб"),
        DocumentFile("Гайдлайн_бренда.pdf", DocumentFile.Kind.PDF, "2,4 Мб"),
        DocumentFile("Редизайн_сайта.pptx", DocumentFile.Kind.PPTX, "6,1 Мб"),
        DocumentFile("Отчет_Q3_2026.xlsx", DocumentFile.Kind.XLSX, "310 Кб"),
        DocumentFile("index.html", DocumentFile.Kind.HTML, "12 Кб"),
        DocumentFile("README.md", DocumentFile.Kind.MD, "4 Кб"),
        DocumentFile("notes.txt", DocumentFile.Kind.TXT, "2 Кб")
    )

    val gallery = listOf(
        MediaItem(R.drawable.gallery_1_office, 634f / 697f),
        MediaItem(R.drawable.gallery_2_server_video, 634f / 697f, isVideo = true),
        MediaItem(R.drawable.gallery_3_robot, 640f / 274f),
        MediaItem(R.drawable.gallery_4_headphones, 440f / 954f)
    )

    val mosaic = listOf(
        MediaItem(R.drawable.mosaic_01, 1200f / 2400f),
        MediaItem(R.drawable.mosaic_02, 720f / 1280f, isVideo = true),
        MediaItem(R.drawable.mosaic_03, 720f / 1280f),
        MediaItem(R.drawable.mosaic_04, 1200f / 1200f),
        MediaItem(R.drawable.mosaic_05, 634f / 697f),
        MediaItem(R.drawable.mosaic_06, 1024f / 1024f),
        MediaItem(R.drawable.mosaic_07, 714f / 1280f),
        MediaItem(R.drawable.mosaic_08, 634f / 697f),
        MediaItem(R.drawable.mosaic_09, 540f / 360f),
        MediaItem(R.drawable.mosaic_10, 703f / 481f)
    )

    val singleVideo = MediaItem(R.drawable.mosaic_10, 703f / 481f, isVideo = true, duration = 10)
    val singlePhoto = MediaItem(R.drawable.single_dunes, 572f / 335f)

    val caption = """
        Первые наброски главной — герой со скриншотом интерфейса вместо абстракции и два
        референса по настроению. На первом кадре то, к чему пришли после трёх итераций:
        заголовок в две строки, под ним одно предложение и две кнопки, справа живой экран
        продукта, а не картинка про технологии. Второй — короткая анимация того же блока,
        видно, как он собирается по шагам и где мы теряем секунду на загрузке. Нижние два
        кадра про свет и материал: холодный тех и предметная съёмка на сером. Смотреть лучше
        подряд, они про одно и то же, просто с разных сторон. Какое направление ближе?
        Если берём холодный, придётся переснимать предметку — это ещё неделя и отдельный
        бюджет на студию. Если мягкий, переделываем герой: там сейчас всё держится на
        контрасте, и в рассеянном свете он рассыплется. Поэтому и спрашиваю до того, как ушли
        в макеты. Переснять проще, чем потом объяснять, почему главная и блог выглядят из
        разных проектов.
    """.trimIndent().replace('\n', ' ')

    val messages = listOf(
        Message(1, true, "17:25",
            MessageContent.Gallery(listOf(singlePhoto), GalleryLayout.SINGLE), width = 297),
        Message(2, false, "17:25", MessageContent.Text(
            "Прошёлся по слайдам и оставил комментарии в разделе «замечания». " +
            "Ниже коротко главное, чтобы не искать по документу."), width = 361),
        Message(3, true, "17:26",
            MessageContent.Text("У меня последние штрихи, минут через 15 скину итог"), width = 278),
        Message(4, false, "17:27", MessageContent.Text("Ок, жду"), width = 112),
        Message(5, false, "17:25", MessageContent.Files(files), width = 341),
        Message(6, false, "17:27",
            MessageContent.Text("Привет! Из нашей переписки в почте"), width = 340),
        Message(7, false, "9:41",
            MessageContent.Gallery(gallery, GalleryLayout.GRID2, caption), width = 341),
        Message(8, false, "9:41",
            MessageContent.Gallery(mosaic, GalleryLayout.MOSAIC), width = 341),
        Message(9, false, "9:41",
            MessageContent.Gallery(listOf(singleVideo), GalleryLayout.SINGLE), width = 341)
    )
}
