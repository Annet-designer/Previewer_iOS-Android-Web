package com.gigachat.mockup.chat

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gigachat.mockup.R
import com.gigachat.mockup.model.*
import com.gigachat.mockup.ui.theme.Token

/**
 * Экран чата. Лента уходит под обе панели с прогрессивным размытием —
 * сообщения не обрезаются линией, а растворяются.
 */
@Composable
fun ChatScreen(
    onOpenFile: (DocumentFile) -> Unit,
    onOpenMedia: (List<MediaItem>, Int, String?) -> Unit
) {
    Box(Modifier.fillMaxSize().background(Token.Surface)) {

        Image(
            painter = painterResource(R.drawable.wallpaper_pattern),
            contentDescription = null,
            contentScale = ContentScale.FillWidth,
            modifier = Modifier.fillMaxSize()
        )

        val listState = rememberLazyListState()
        LaunchedEffect(Unit) { listState.scrollToItem(SampleData.messages.lastIndex) }

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(
                top = Token.Layout.FeedTop,
                bottom = Token.Layout.FeedBottom
            ),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(SampleData.messages, key = { it.id }) { message ->
                MessageRow(message, onOpenFile, onOpenMedia)
            }
        }

        TopBar(Modifier.align(Alignment.TopCenter))
        BottomBar(Modifier.align(Alignment.BottomCenter))
    }
}

// ---- Верхняя панель ----

@Composable
private fun TopBar(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(Token.Layout.TopBar)) {

        // Вуаль под панелью: цвет плюс нарастающее размытие.
        Box(
            Modifier
                .fillMaxWidth()
                .height(136.dp)
                .background(
                    Brush.verticalGradient(
                        0f to Token.Surface,
                        0.54f to Token.Surface,
                        1f to Color.Transparent
                    )
                )
        )

        Column {
            MaterialStatusBar()
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().height(Token.Layout.AppBar).padding(8.dp)
            ) {
                CircleIcon(R.drawable.icon_back, tint = Token.AccentDark)
                Spacer(Modifier.width(4.dp))
                PeerPill(Modifier.weight(1f))
                Spacer(Modifier.width(4.dp))
                CircleIcon(R.drawable.icon_more, tint = Token.AccentDark)
            }
        }
    }
}

@Composable
private fun PeerPill(modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(Token.Radius.Pill))
            .background(Token.Paper)
            .padding(start = 4.dp, end = 12.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.avatar_ivan),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(36.dp).clip(CircleShape)
        )
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Иван Петров", style = Token.Type.BodyMedium, color = Token.Ink,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("В сети", style = Token.Type.Footnote, color = Token.AccentDark)
        }
    }
}

@Composable
private fun MaterialStatusBar(dark: Boolean = false) {
    val tint = if (dark) Color.White else Token.OnSurfaceM3
    Box(Modifier.fillMaxWidth().height(Token.Layout.StatusBar)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 10.dp)
        ) {
            Text("9:30", style = Token.Type.StatusBar, color = tint)
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Icon(painterResource(R.drawable.status_wifi), null, Modifier.size(17.dp), tint)
                Icon(painterResource(R.drawable.status_signal), null, Modifier.size(17.dp), tint)
                Icon(painterResource(R.drawable.status_battery), null, Modifier.size(8.dp, 15.dp), tint)
            }
        }
        // Вырез камеры по центру.
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 18.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFF0B0B0B))
        )
    }
}

// ---- Нижняя панель ----

@Composable
private fun BottomBar(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth()) {

        Row(
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .height(40.dp)
                    .shadow(4.dp, RoundedCornerShape(Token.Radius.Pill))
                    .clip(RoundedCornerShape(Token.Radius.Pill))
                    .background(Token.Paper)
                    .padding(horizontal = 10.dp)
            ) {
                Icon(painterResource(R.drawable.icon_summarize), null, Modifier.size(24.dp), Token.Ink)
                Spacer(Modifier.width(2.dp))
                Text("Саммари", style = Token.Type.BodyMedium, color = Token.Ink)
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .size(40.dp)
                    .shadow(4.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Token.Paper),
                contentAlignment = Alignment.Center
            ) {
                Image(painterResource(R.drawable.icon_gigachat), null, Modifier.size(24.dp))
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .padding(horizontal = 12.dp)
                .fillMaxWidth()
                .height(48.dp)
                .shadow(4.dp, RoundedCornerShape(32.dp))
                .clip(RoundedCornerShape(32.dp))
                .background(Token.Paper)
                .padding(4.dp)
        ) {
            Icon(painterResource(R.drawable.icon_plus), null, Modifier.size(24.dp).padding(0.dp), Token.Ink)
            Spacer(Modifier.width(12.dp))
            Text("Сообщение", style = Token.Type.Body, color = Token.InkTertiary,
                modifier = Modifier.weight(1f))
            Icon(painterResource(R.drawable.icon_sticker), null, Modifier.size(24.dp), Token.Ink)
            Spacer(Modifier.width(16.dp))
            Icon(painterResource(R.drawable.icon_mic), null, Modifier.size(24.dp), Token.Ink)
        }

        GestureBar()
    }
}

@Composable
fun GestureBar(light: Boolean = false) {
    Box(Modifier.fillMaxWidth().height(Token.Layout.NavBar), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(108.dp, 4.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (light) Color.White else Token.NavPill)
        )
    }
}

@Composable
fun CircleIcon(icon: Int, tint: Color = Token.Ink, size: androidx.compose.ui.unit.Dp = 44.dp) {
    Surface(
        shape = CircleShape,
        color = Token.Paper,
        modifier = Modifier.size(size)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(painterResource(icon), null, Modifier.size(24.dp), tint)
        }
    }
}
