package com.gigachat.mockup.chat

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gigachat.mockup.R
import com.gigachat.mockup.model.*
import com.gigachat.mockup.ui.theme.Token

@Composable
fun MessageRow(
    message: Message,
    onOpenFile: (DocumentFile) -> Unit,
    onOpenMedia: (List<MediaItem>, Int, String?) -> Unit
) {
    val isMedia = message.content is MessageContent.Gallery
    Row(
        horizontalArrangement = if (message.isOutgoing) Arrangement.End else Arrangement.Start,
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                start = if (message.isOutgoing) (if (isMedia) 42 else 87).dp else 10.dp,
                end   = if (message.isOutgoing) 10.dp else (if (isMedia) 40 else 40).dp
            )
    ) {
        Box(
            Modifier
                .then(message.width?.let { Modifier.width(it.dp) } ?: Modifier)
                .drawBehind { drawTail(message.isOutgoing) }
                .clip(if (message.isOutgoing) Token.BubbleOut else Token.BubbleIn)
                .then(
                    if (message.isOutgoing) Modifier.background(Token.OutgoingBubble)
                    else Modifier.background(Token.Paper)
                )
        ) {
            when (val content = message.content) {
                is MessageContent.Text -> TextBubble(message, content.value)
                is MessageContent.Files -> FilesBubble(message, content.files, onOpenFile)
                is MessageContent.Gallery -> GalleryBubble(message, content, onOpenMedia)
            }
        }
    }
}

/**
 * Хвостик пузыря. Рисуется контуром, а не картинкой: масштабируется без
 * потери качества и берёт цвет пузыря.
 */
private fun DrawScope.drawTail(isOutgoing: Boolean) {
    val w = 12.dp.toPx()
    val h = 16.dp.toPx()
    val path = Path().apply {
        if (isOutgoing) {
            val x = size.width - 1.dp.toPx()
            moveTo(x, size.height)
            lineTo(x, size.height - h + 2.dp.toPx())
            cubicTo(
                x, size.height - h * 0.45f,
                x + w * 0.35f, size.height - h * 0.15f,
                x + w, size.height
            )
        } else {
            val x = 1.dp.toPx()
            moveTo(x, size.height)
            lineTo(x, size.height - h + 2.dp.toPx())
            cubicTo(
                x, size.height - h * 0.45f,
                x - w * 0.35f, size.height - h * 0.15f,
                x - w, size.height
            )
        }
        close()
    }
    drawPath(path, if (isOutgoing) Token.AccentDeep else Token.Paper)
}

// ---- Текст ----

@Composable
private fun TextBubble(message: Message, text: String) {
    Box {
        // Метка времени садится в конец последней строки: хвост из
        // неразрывных пробелов резервирует ей место, как в мокапе.
        Text(
            text + "\u00A0".repeat(if (message.isOutgoing) 8 else 6),
            style = Token.Type.Body,
            color = if (message.isOutgoing) Color.White else Token.Ink,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
        )
        Timestamp(message, Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
private fun Timestamp(message: Message, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            message.time,
            style = Token.Type.Caption,
            color = if (message.isOutgoing) Color.White.copy(alpha = 0.64f) else Token.InkSecondary
        )
        if (message.isOutgoing) {
            Spacer(Modifier.width(2.dp))
            Icon(painterResource(R.drawable.icon_check), null, Modifier.size(16.dp),
                Color.White.copy(alpha = 0.64f))
        }
    }
}

// ---- Файлы ----

@Composable
private fun FilesBubble(
    message: Message,
    files: List<DocumentFile>,
    onOpenFile: (DocumentFile) -> Unit
) {
    Box {
        Column(
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(horizontal = 9.dp).padding(top = 5.dp, bottom = 24.dp)
        ) {
            files.forEach { file -> FileRow(file) { onOpenFile(file) } }
        }
        Timestamp(message, Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
private fun FileRow(file: DocumentFile, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(Token.Radius.File))
            .background(Token.Accent.copy(alpha = 0.12f))
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
            Image(painterResource(R.drawable.file_sheet), null, Modifier.size(40.dp))
            Image(painterResource(R.drawable.file_corner), null,
                Modifier.size(13.dp).align(Alignment.TopEnd))
            Text(file.kind.badge, style = Token.Type.Subhead, color = Token.AccentDark)
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(file.name, style = Token.Type.Subhead, color = Token.Ink,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(file.size, style = Token.Type.Footnote, color = Token.InkSecondary)
        }
        Icon(painterResource(R.drawable.icon_download), null,
            Modifier.size(24.dp), Token.AccentDark)
    }
}

// ---- Галерея ----

@Composable
private fun GalleryBubble(
    message: Message,
    gallery: MessageContent.Gallery,
    onOpenMedia: (List<MediaItem>, Int, String?) -> Unit
) {
    Box {
        Column {
            GalleryView(gallery.items, gallery.layout) { index ->
                onOpenMedia(gallery.items, index, gallery.caption)
            }
            gallery.caption?.let { caption ->
                Text(
                    caption,
                    style = Token.Type.Body,
                    color = if (message.isOutgoing) Color.White else Token.Ink,
                    modifier = Modifier.padding(horizontal = 9.dp).padding(top = 6.dp, bottom = 20.dp)
                )
            }
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(if (gallery.caption == null) 4.dp else 0.dp)) {
            if (gallery.caption == null) {
                // На медиа метка садится в тёмную плашку.
                Box(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(Token.OverlayMedium)
                ) { Timestamp(message) }
            } else {
                Timestamp(message)
            }
        }
    }
}

@Composable
private fun GalleryView(
    items: List<MediaItem>,
    layout: GalleryLayout,
    onTap: (Int) -> Unit
) {
    when (layout) {
        GalleryLayout.GRID2 -> Column(
            verticalArrangement = Arrangement.spacedBy(1.dp),
            modifier = Modifier.clip(
                RoundedCornerShape(topStart = Token.Radius.Media, topEnd = Token.Radius.Media)
            )
        ) {
            for (row in 0 until 2) {
                Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                    for (column in 0 until 2) {
                        val index = row * 2 + column
                        if (index < items.size) Tile(items[index], 169.dp, 161.dp) { onTap(index) }
                    }
                }
            }
        }

        GalleryLayout.MOSAIC -> Column(
            verticalArrangement = Arrangement.spacedBy(1.dp),
            modifier = Modifier.clip(RoundedCornerShape(Token.Radius.Media))
        ) {
            MosaicRow(items, 0..1, 169.dp, 161.dp, onTap)
            MosaicRow(items, 2..4, 112.33.dp, 107.dp, onTap)
            MosaicRow(items, 5..6, 169.dp, 161.dp, onTap)
            MosaicRow(items, 7..9, 112.33.dp, 107.dp, onTap)
        }

        GalleryLayout.SINGLE -> Tile(
            items[0],
            width = null,
            height = null,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(items[0].aspect)
                .clip(RoundedCornerShape(Token.Radius.Media))
        ) { onTap(0) }
    }
}

@Composable
private fun MosaicRow(
    items: List<MediaItem>,
    range: IntRange,
    width: androidx.compose.ui.unit.Dp,
    height: androidx.compose.ui.unit.Dp,
    onTap: (Int) -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        range.forEach { index ->
            if (index < items.size) Tile(items[index], width, height) { onTap(index) }
        }
    }
}

@Composable
private fun Tile(
    item: MediaItem,
    width: androidx.compose.ui.unit.Dp?,
    height: androidx.compose.ui.unit.Dp?,
    modifier: Modifier = Modifier,
    onTap: () -> Unit
) {
    Box(
        modifier
            .then(if (width != null && height != null) Modifier.size(width, height) else Modifier)
            .clickable(onClick = onTap),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(item.asset),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (item.isVideo) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Token.OverlayMedium),
                contentAlignment = Alignment.Center
            ) {
                Icon(painterResource(R.drawable.icon_play_badge), null,
                    Modifier.size(16.dp), Color.White)
            }
        }
    }
}
