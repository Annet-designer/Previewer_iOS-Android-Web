import SwiftUI

// MARK: - Цвет

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red:   Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >>  8) & 0xFF) / 255,
            blue:  Double( hex        & 0xFF) / 255,
            opacity: opacity
        )
    }
}

/// Токены из Pixso-экспорта. Значения совпадают с `tokens/tokens.css` в паке.
enum Token {

    // MARK: Палитра
    static let accent      = Color(hex: 0x0BA686)
    static let accentDark  = Color(hex: 0x0A8E73)
    static let accentDeep  = Color(hex: 0x09856B)

    static let ink         = Color(hex: 0x15110F)
    static let inkSecondary = Color(hex: 0x15110F, opacity: 0.64)
    static let inkTertiary  = Color(hex: 0x15110F, opacity: 0.24)

    static let surface     = Color(hex: 0xF0F0F0)
    static let surfaceCard = Color(hex: 0xF5F5F5)
    static let paper       = Color.white
    static let backdropDark = Color(hex: 0x141413)

    static let destructive = Color(hex: 0xFF3B30)
    static let overlayMedium = Color.black.opacity(0.32)

    /// Заливка исходящего пузыря.
    static var outgoingBubble: LinearGradient {
        LinearGradient(
            colors: [accent, accentDeep],
            startPoint: .leading,
            endPoint: .trailing
        )
    }

    // MARK: Скругления
    enum Radius {
        static let screen: CGFloat = 54
        static let sheet:  CGFloat = 38
        static let bubble: CGFloat = 16
        static let pill:   CGFloat = 1000
        static let menu:   CGFloat = 32
        static let menuItem: CGFloat = 22
        static let pip:    CGFloat = 14
    }

    // MARK: Геометрия экрана
    enum Layout {
        static let screen = CGSize(width: 393, height: 852)
        static let statusBar: CGFloat = 62
        static let navBar: CGFloat = 44
        /// Полная высота верхней панели: статус-бар + шапка.
        static let topBar: CGFloat = statusBar + navBar          // 106
        static let chatTopInset: CGFloat = 120
        static let chatBottomInset: CGFloat = 136
    }

    // MARK: Типографика
    ///
    /// В вебе трекинг задавался вручную (−0.4 для тела). В UIKit/SwiftUI
    /// системный шрифт уже несёт правильный трекинг для каждого размера,
    /// поэтому `.tracking` здесь не выставляется — иначе текст «поплывёт»
    /// относительно системных контролов.
    enum Font_ {
        static let body      = Font.system(size: 17)
        static let bodyMedium = Font.system(size: 17, weight: .medium)
        static let subhead   = Font.system(size: 15)
        static let footnote  = Font.system(size: 13)
        static let caption   = Font.system(size: 12)
        static let timestamp = Font.system(size: 11)
        static let menuItem  = Font.system(size: 18)
        static let title     = Font.system(size: 16, weight: .semibold)
    }

    // MARK: Тени
    enum Shadow {
        static let soft = (color: Color.black.opacity(0.09), radius: CGFloat(10), y: CGFloat(4))
        static let menu = (color: Color.black.opacity(0.26), radius: CGFloat(22), y: CGFloat(9))
        static let pip  = (color: Color.black.opacity(0.30), radius: CGFloat(16), y: CGFloat(6))
    }

    // MARK: Тайминги
    ///
    /// Собраны замерами по мокапу. Кривые подобраны так, чтобы появление
    /// начиналось быстро, а уход — мягко.
    enum Motion {
        /// Возврат обвязки в просмотрщике.
        static let chromeIn  = Animation.timingCurve(0.32, 0.72, 0, 1, duration: 0.34)
        /// Уход обвязки за края экрана.
        static let chromeOut = Animation.timingCurve(0.5, 0, 0.75, 0, duration: 0.30)
        /// Раскрытие контекстного меню каплей.
        static let menuPop   = Animation.timingCurve(0.25, 0.9, 0.3, 1, duration: 0.34)
        static let menuHide  = Animation.timingCurve(0.4, 0, 1, 1, duration: 0.17)
        /// Примагничивание мини-экрана к углу.
        static let pipSnap   = Animation.spring(response: 0.34, dampingFraction: 0.78)
        /// Раскрытие миниатюры в ленте.
        static let thumb     = Animation.timingCurve(0.2, 0.7, 0.3, 1, duration: 0.28)

        /// Через сколько после старта воспроизведения уходит обвязка.
        static let hideAfterPlay: TimeInterval = 1.0
        /// То же после возвращающего тапа — окно для взаимодействия шире.
        static let hideAfterTap: TimeInterval = 3.0
        /// Сколько живёт счётчик кадров и страниц.
        static let counterLifetime: TimeInterval = 2.0
    }
}
