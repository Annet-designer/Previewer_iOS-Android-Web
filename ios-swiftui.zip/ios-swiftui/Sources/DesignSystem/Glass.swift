import SwiftUI

// MARK: - Стекло

/// Полупрозрачная поверхность с обводкой-градиентом.
///
/// В мокапе это собиралось вручную из `backdrop-filter`, линейного
/// градиента и двух псевдоэлементов. В SwiftUI за размытие отвечает
/// системный материал, поэтому руками остаётся только обвод и тон.
///
/// На iOS 26 вместо этого модификатора стоит взять системный
/// `.glassEffect(.regular, in: shape)` — он даёт живое преломление,
/// которое в вебе воспроизвести было нечем.
struct GlassBackground: ViewModifier {
    enum Tone { case light, dark }

    var tone: Tone = .light
    var shape: AnyShape = AnyShape(Capsule())

    func body(content: Content) -> some View {
        content
            .background {
                shape
                    .fill(.ultraThinMaterial)
                    .overlay {
                        shape.fill(
                            LinearGradient(
                                colors: tone == .light
                                    ? [.white.opacity(0.80), .white.opacity(0.60)]
                                    : [Color(hex: 0x444444, opacity: 0.13),
                                       Color(hex: 0x494949, opacity: 0.75)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    }
                    .overlay {
                        // Обвод: сверху ярче, к низу гаснет и снова проявляется.
                        shape.strokeBorder(
                            LinearGradient(
                                colors: tone == .light
                                    ? [.white, .white.opacity(0.16), .white.opacity(0.80)]
                                    : [.white.opacity(0.80), .white.opacity(0.08), .white],
                                startPoint: .top,
                                endPoint: .bottom
                            ),
                            lineWidth: 0.5
                        )
                    }
            }
            .foregroundStyle(tone == .light ? Token.ink : .white)
    }
}

extension View {
    func glass(_ tone: GlassBackground.Tone = .light, shape: some Shape = Capsule()) -> some View {
        modifier(GlassBackground(tone: tone, shape: AnyShape(shape)))
    }
}

// MARK: - Хвостик пузыря

/// Лапка, вытекающая из нижнего угла пузыря.
///
/// В мокапе это была картинка 12×15. Здесь — путь: он масштабируется без
/// потери качества и красится в цвет пузыря.
struct BubbleTail: Shape {
    var isOutgoing: Bool

    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width, h = rect.height
        if isOutgoing {
            p.move(to: CGPoint(x: 0, y: h))
            p.addLine(to: CGPoint(x: 0, y: h * 0.13))
            p.addCurve(
                to: CGPoint(x: w, y: h),
                control1: CGPoint(x: 0, y: h * 0.55),
                control2: CGPoint(x: w * 0.35, y: h * 0.85)
            )
        } else {
            p.move(to: CGPoint(x: w, y: h))
            p.addLine(to: CGPoint(x: w, y: h * 0.13))
            p.addCurve(
                to: CGPoint(x: 0, y: h),
                control1: CGPoint(x: w, y: h * 0.55),
                control2: CGPoint(x: w * 0.65, y: h * 0.85)
            )
        }
        p.closeSubpath()
        return p
    }
}

// MARK: - Прогрессивное размытие

/// Полоса, в которой размытие нарастает к краю.
///
/// Одного `.blur` мало: он даёт равномерную муть с видимой ступенькой на
/// границе. Здесь тот же приём, что в мокапе, — несколько слоёв с разным
/// радиусом, каждый со своей маской-градиентом.
///
/// Системного variable blur в публичном API нет; если он появится,
/// эту конструкцию можно заменить одним вызовом.
struct ProgressiveBlur: View {
    enum Edge { case top, bottom }

    var edge: Edge
    var height: CGFloat
    /// Радиусы слоёв от слабого к сильному.
    var radii: [CGFloat] = [1, 2, 4, 9, 18]

    var body: some View {
        ZStack {
            ForEach(Array(radii.enumerated()), id: \.offset) { index, radius in
                let step = Double(index + 1) / Double(radii.count)
                Rectangle()
                    .fill(.clear)
                    .background(.ultraThinMaterial)
                    .blur(radius: radius, opaque: false)
                    .mask {
                        LinearGradient(
                            stops: [
                                .init(color: .black, location: 0),
                                .init(color: .black, location: 0.55 * (1 - step) + 0.04),
                                .init(color: .clear, location: 0.90 * (1 - step) + 0.22)
                            ],
                            startPoint: edge == .bottom ? .bottom : .top,
                            endPoint:   edge == .bottom ? .top    : .bottom
                        )
                    }
            }
        }
        .frame(height: height)
        .allowsHitTesting(false)
    }
}
