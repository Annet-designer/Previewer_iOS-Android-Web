import SwiftUI

/// Раскладки медиа внутри пузыря: сетка 2×2, мозаика и одиночный кадр.
struct GalleryView: View {
    let items: [MediaItem]
    let layout: Message.GalleryLayout
    var onTap: (Int) -> Void

    var body: some View {
        switch layout {
        case .grid2:  grid2
        case .mosaic: mosaic
        case .single: single
        }
    }

    // MARK: 2×2

    private var grid2: some View {
        VStack(spacing: 1) {
            ForEach(0..<2, id: \.self) { row in
                HStack(spacing: 1) {
                    ForEach(0..<2, id: \.self) { column in
                        let index = row * 2 + column
                        if index < items.count {
                            tile(index).frame(width: 169, height: 161)
                        }
                    }
                }
            }
        }
        // Скругление только сверху: снизу к галерее примыкает подпись.
        .clipShape(UnevenRoundedRectangle(
            topLeadingRadius: 15, bottomLeadingRadius: 0,
            bottomTrailingRadius: 0, topTrailingRadius: 15, style: .continuous))
    }

    // MARK: Мозаика 2 / 3 / 2 / 3

    private var mosaic: some View {
        VStack(spacing: 1) {
            mosaicRow(range: 0..<2, height: 161, width: 169)
            mosaicRow(range: 2..<5, height: 107, width: 112.33)
            mosaicRow(range: 5..<7, height: 161, width: 169)
            mosaicRow(range: 7..<10, height: 107, width: 112.33)
        }
        .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
    }

    private func mosaicRow(range: Range<Int>, height: CGFloat, width: CGFloat) -> some View {
        HStack(spacing: 1) {
            ForEach(range, id: \.self) { index in
                if index < items.count {
                    tile(index).frame(width: width, height: height)
                }
            }
        }
    }

    // MARK: Один кадр

    private var single: some View {
        tile(0)
            .aspectRatio(items[0].aspect, contentMode: .fit)
            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
    }

    // MARK: Кадр

    private func tile(_ index: Int) -> some View {
        let item = items[index]
        return Color.clear
            .overlay {
                Image(item.asset).resizable().scaledToFill()
            }
            .clipped()
            .overlay {
                if item.isVideo {
                    Image(systemName: "play.fill")
                        .font(.system(size: 15))
                        .foregroundStyle(.white)
                        .frame(width: 40, height: 40)
                        .background(.black.opacity(0.32), in: Circle())
                }
            }
            .contentShape(Rectangle())
            .onTapGesture { onTap(index) }
    }
}
