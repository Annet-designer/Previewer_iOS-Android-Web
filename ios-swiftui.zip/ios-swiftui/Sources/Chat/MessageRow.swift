import SwiftUI

struct MessageRow: View {
    let message: Message
    var onFileTap: (DocumentFile) -> Void
    var onMediaTap: ([MediaItem], Int, String?) -> Void

    var body: some View {
        HStack(spacing: 0) {
            if message.isOutgoing { Spacer(minLength: leadingInset) }
            bubble
            if !message.isOutgoing { Spacer(minLength: trailingInset) }
        }
        .padding(.horizontal, 10)
    }

    /// Поля рядов из макета: у текста они шире, у медиа уже.
    private var leadingInset: CGFloat { isMedia ? 32 : 77 }
    private var trailingInset: CGFloat { isMedia ? 32 : 32 }

    private var isMedia: Bool {
        if case .gallery = message.content { return true }
        return false
    }

    private var bubble: some View {
        content
            .frame(width: message.width)
            .background {
                Group {
                    if message.isOutgoing {
                        RoundedRectangle(cornerRadius: Token.Radius.bubble, style: .continuous)
                            .fill(Token.outgoingBubble)
                    } else {
                        RoundedRectangle(cornerRadius: Token.Radius.bubble, style: .continuous)
                            .fill(Token.paper)
                    }
                }
            }
            .overlay(alignment: message.isOutgoing ? .bottomTrailing : .bottomLeading) {
                BubbleTail(isOutgoing: message.isOutgoing)
                    .fill(message.isOutgoing ? Token.accentDeep : Token.paper)
                    .frame(width: 12, height: 15)
                    .offset(x: message.isOutgoing ? 5 : -5)
            }
            .clipShape(RoundedRectangle(cornerRadius: Token.Radius.bubble, style: .continuous)
                .offset(x: 0))   // клип не должен срезать хвостик
    }

    @ViewBuilder
    private var content: some View {
        switch message.content {
        case .text(let string):
            textBubble(string)

        case .files(let files):
            VStack(spacing: 4) {
                ForEach(files) { file in
                    FileRow(file: file) { onFileTap(file) }
                }
            }
            .padding(.horizontal, 9)
            .padding(.top, 5)
            .padding(.bottom, 24)
            .overlay(alignment: .bottomTrailing) { timestamp }

        case .gallery(let items, let layout, let caption):
            VStack(spacing: 0) {
                GalleryView(items: items, layout: layout) { index in
                    onMediaTap(items, index, caption)
                }
                if let caption {
                    Text(caption)
                        .font(Token.Font_.body)
                        .foregroundStyle(message.isOutgoing ? .white : Token.ink)
                        .padding(.horizontal, 9)
                        .padding(.top, 6)
                        .padding(.bottom, 20)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .overlay(alignment: .bottomTrailing) {
                timestamp.padding(caption == nil ? 4 : 0)
            }
        }
    }

    private func textBubble(_ string: String) -> some View {
        // Метка времени садится в конец последней строки: хвост из
        // неразрывных пробелов резервирует ей место, как в мокапе.
        Text(string + "\u{00a0}\u{00a0}\u{00a0}\u{00a0}\u{00a0}\u{00a0}")
            .font(Token.Font_.body)
            .foregroundStyle(message.isOutgoing ? .white : Token.ink)
            .padding(.horizontal, 9)
            .padding(.vertical, 6)
            .frame(maxWidth: .infinity, alignment: .leading)
            .overlay(alignment: .bottomTrailing) { timestamp }
    }

    private var timestamp: some View {
        HStack(spacing: 2) {
            Text(message.time)
            if message.isOutgoing {
                Image(systemName: "checkmark").font(.system(size: 9, weight: .semibold))
            }
        }
        .font(Token.Font_.timestamp)
        .foregroundStyle(message.isOutgoing ? .white.opacity(0.64) : Token.inkSecondary)
        .padding(.horizontal, 8)
        .padding(.vertical, 3)
    }
}

// MARK: - Плашка файла

struct FileRow: View {
    let file: DocumentFile
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                ZStack {
                    Image("file-sheet").resizable().frame(width: 40, height: 40)
                    Image("file-corner").resizable().frame(width: 13, height: 13)
                        .offset(x: 13.5, y: -13.5)
                    Text(file.kind.badge)
                        .font(.system(size: 13))
                        .foregroundStyle(Token.accentDark)
                        .offset(y: 2)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(file.name)
                        .font(Token.Font_.subhead)
                        .foregroundStyle(Token.ink)
                        .lineLimit(1).truncationMode(.middle)
                    Text(file.size)
                        .font(Token.Font_.footnote)
                        .foregroundStyle(Token.inkSecondary)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.down.circle")
                    .font(.system(size: 22))
                    .foregroundStyle(Token.accentDark)
            }
            .padding(8)
            .frame(height: 56)
            .background(Token.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}
