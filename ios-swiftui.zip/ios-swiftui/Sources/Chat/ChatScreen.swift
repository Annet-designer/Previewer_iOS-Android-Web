import SwiftUI

/// Экран чата. Лента уходит под обе панели с прогрессивным размытием —
/// сообщения не обрезаются линией, а растворяются.
struct ChatScreen: View {
    @State private var openedFile: DocumentFile?
    @State private var viewerContext: ViewerContext?

    var body: some View {
        ZStack {
            Token.surface.ignoresSafeArea()
            Image("wallpaper-pattern")
                .resizable(resizingMode: .tile)
                .ignoresSafeArea()
                .opacity(0.9)

            feed
            topBar
            bottomBar
        }
        .fullScreenCover(item: $openedFile) { file in
            DocumentSheet(file: file)
        }
        .fullScreenCover(item: $viewerContext) { ctx in
            MediaViewer(items: ctx.items, startIndex: ctx.index, caption: ctx.caption)
        }
    }

    // MARK: Лента

    private var feed: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 8) {
                    ForEach(SampleData.messages) { message in
                        MessageRow(
                            message: message,
                            onFileTap: { openedFile = $0 },
                            onMediaTap: { items, index, caption in
                                viewerContext = ViewerContext(items: items, index: index, caption: caption)
                            }
                        )
                        .id(message.id)
                    }
                    Color.clear.frame(height: 1).id("bottom")
                }
                .padding(.top, Token.Layout.chatTopInset)
                .padding(.bottom, Token.Layout.chatBottomInset)
            }
            .scrollIndicators(.hidden)
            .onAppear { proxy.scrollTo("bottom", anchor: .bottom) }
        }
    }

    // MARK: Верхняя панель

    private var topBar: some View {
        VStack(spacing: 0) {
            ZStack(alignment: .bottom) {
                ProgressiveBlur(edge: .top, height: 136)
                    .overlay {
                        LinearGradient(
                            stops: [
                                .init(color: Token.surface, location: 0),
                                .init(color: Token.surface.opacity(0.72), location: 0.38),
                                .init(color: .clear, location: 0.92)
                            ],
                            startPoint: .top, endPoint: .bottom
                        )
                        .allowsHitTesting(false)
                    }

                HStack(spacing: 12) {
                    CircleButton(systemName: "chevron.backward") {}
                    peerPill
                    CircleButton(systemName: "phone.fill") {}
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 12)
            }
            .frame(height: 136)
            Spacer()
        }
        .ignoresSafeArea()
    }

    private var peerPill: some View {
        HStack(spacing: 8) {
            Image("avatar-ivan")
                .resizable().scaledToFill()
                .frame(width: 36, height: 36)
                .clipShape(Circle())
            VStack(alignment: .leading, spacing: 0) {
                Text("Иван Петров").font(Token.Font_.title)
                Text("В сети")
                    .font(Token.Font_.caption)
                    .foregroundStyle(Token.accentDark)
            }
            Spacer(minLength: 0)
        }
        .padding(.leading, 4)
        .padding(.trailing, 12)
        .frame(height: 44)
        .glass(.light)
    }

    // MARK: Нижняя панель

    private var bottomBar: some View {
        VStack(spacing: 0) {
            Spacer()
            ZStack(alignment: .bottom) {
                ProgressiveBlur(edge: .bottom, height: 140)
                    .overlay {
                        LinearGradient(
                            stops: [
                                .init(color: Token.surface, location: 0),
                                .init(color: Token.surface.opacity(0.72), location: 0.38),
                                .init(color: .clear, location: 0.92)
                            ],
                            startPoint: .bottom, endPoint: .top
                        )
                        .allowsHitTesting(false)
                    }

                VStack(spacing: 8) {
                    HStack(spacing: 8) {
                        Spacer()
                        Button {} label: {
                            HStack(spacing: 2) {
                                Image(systemName: "text.line.first.and.arrowtriangle.forward")
                                Text("Саммари").font(Token.Font_.bodyMedium)
                            }
                            .padding(.horizontal, 12)
                            .frame(height: 40)
                            .glass(.light)
                        }
                        Button {} label: {
                            Image("icon-gigachat").resizable().frame(width: 24, height: 24)
                                .padding(8)
                                .glass(.light, shape: Circle())
                        }
                    }
                    composer
                }
                .padding(.horizontal, 10)
                .padding(.bottom, 34)
                .buttonStyle(.plain)
            }
            .frame(height: 140)
        }
        .ignoresSafeArea()
    }

    private var composer: some View {
        HStack(spacing: 0) {
            Image(systemName: "plus").frame(width: 40, height: 40)
            Text("Сообщение")
                .font(Token.Font_.body)
                .foregroundStyle(Token.inkTertiary)
                .frame(maxWidth: .infinity, alignment: .leading)
            Image(systemName: "face.smiling").frame(width: 40, height: 40)
            Image(systemName: "mic").frame(width: 40, height: 40)
        }
        .padding(.horizontal, 4)
        .frame(height: 48)
        .glass(.light)
    }
}

// MARK: - Вспомогательное

/// Что открыть в просмотрщике. Отдельный тип нужен, чтобы
/// `fullScreenCover(item:)` получил `Identifiable`.
struct ViewerContext: Identifiable {
    let id = UUID()
    let items: [MediaItem]
    let index: Int
    let caption: String?
}

struct CircleButton: View {
    var systemName: String
    var tone: GlassBackground.Tone = .light
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 17, weight: .semibold))
                .frame(width: 44, height: 44)
                .glass(tone, shape: Circle())
        }
        .buttonStyle(.plain)
    }
}
