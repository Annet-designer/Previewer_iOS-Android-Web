import SwiftUI

@main
struct GigaChatMockupApp: App {
    var body: some Scene {
        WindowGroup {
            ChatScreen()
                .preferredColorScheme(.light)
        }
    }
}
