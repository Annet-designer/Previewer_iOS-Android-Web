import SwiftUI

/// Отрисовка страницы по типу файла.
///
/// В мокапе содержимое было свёрстано целиком — семь наборов вручную.
/// Здесь оставлена структура и по одному характерному блоку на тип:
/// в проекте на это место встанет реальный рендер (PDFKit, QuickLook,
/// WKWebView), а разметка нужна, чтобы видеть раскладку и отступы.
struct DocumentPage: View {
    let kind: DocumentFile.Kind
    let number: Int

    var body: some View {
        switch kind {
        case .docx, .pdf: paper
        case .pptx:       slide
        case .xlsx:       sheet
        case .html:       web
        case .md, .txt:   plain
        }
    }

    // MARK: A4

    private var paper: some View {
        VStack(alignment: .leading, spacing: 10) {
            if number == 1 {
                Text(kind == .pdf ? "Гайдлайн бренда" : "Дизайн-концепция сайта")
                    .font(.system(size: 20, weight: .bold))
                Text("Версия 2.4 · отдел дизайна · сентябрь 2026")
                    .font(.system(size: 7))
                    .foregroundStyle(Token.inkSecondary)
            }
            ForEach(0..<6, id: \.self) { _ in
                Text(String(repeating: "Текст страницы. ", count: 12))
                    .font(.system(size: 7))
                    .foregroundStyle(Token.ink)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 36.5)
        .padding(.vertical, 35.6)
        .frame(width: 393, height: 546, alignment: .topLeading)
        .background(Token.paper)
    }

    // MARK: Слайд 16:9

    private var slide: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Слайд \(number)").font(.system(size: 13, weight: .semibold))
            Text("Подзаголовок раздела")
                .font(.system(size: 8))
                .foregroundStyle(Token.inkSecondary)
            Spacer()
        }
        .padding(16)
        .frame(width: 361, height: 203, alignment: .topLeading)
        .background(Token.paper)
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .padding(.horizontal, 16)
    }

    // MARK: Таблица

    private var sheet: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(number == 1 ? "Трафик по разделам" : "Конверсии по источникам")
                .font(.system(size: 11, weight: .semibold))
                .padding(8)
            ForEach(0..<10, id: \.self) { row in
                HStack(spacing: 0) {
                    ForEach(0..<5, id: \.self) { column in
                        Text(row == 0 ? "Колонка \(column + 1)" : "—")
                            .font(.system(size: 7))
                            .frame(maxWidth: .infinity, minHeight: 18)
                            .background(row == 0 ? Token.accent.opacity(0.12) : .clear)
                            .border(Token.inkTertiary.opacity(0.4), width: 0.3)
                    }
                }
            }
        }
        .frame(width: 393, alignment: .topLeading)
        .background(Token.paper)
    }

    // MARK: Веб-страница и код

    private var web: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(number == 1 ? "Рендер страницы" : "Исходный код")
                .font(.system(size: 11, weight: .semibold))
            Text(number == 1
                 ? "Здесь показывается сайт целиком."
                 : "<!DOCTYPE html>\n<html lang=\"ru\">\n  <head>…</head>\n</html>")
                .font(.system(size: 7, design: number == 1 ? .default : .monospaced))
                .foregroundStyle(Token.inkSecondary)
            Spacer(minLength: 0)
        }
        .padding(18)
        .frame(width: 393, height: 420, alignment: .topLeading)
        .background(Token.paper)
    }

    // MARK: Текст

    private var plain: some View {
        Text(String(repeating: "заметки со встречи по редизайну\n", count: 20))
            .font(.system(size: 7, design: .monospaced))
            .foregroundStyle(Token.ink)
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .frame(width: 393, alignment: .topLeading)
            .background(Token.paper)
    }
}
