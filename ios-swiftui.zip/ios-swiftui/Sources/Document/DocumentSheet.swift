import SwiftUI

/// Превьюер документа. Открывается на весь экран, чат уезжает назад.
struct DocumentSheet: View {
    let file: DocumentFile

    @Environment(\.dismiss) private var dismiss
    @State private var scrollOffset: CGFloat = 0
    @State private var currentPage = 1
    @State private var counterVisible = false
    @State private var menuShown = false
    @State private var counterTask: Task<Void, Never>?

    /// На первых 100 точках прокрутки обвязка схлопывается.
    private var chromeScale: CGFloat { max(0, 1 - scrollOffset / 100) }

    var body: some View {
        ZStack(alignment: .top) {
            Token.surfaceCard.ignoresSafeArea()
            pages
            header
            counter
            toolbar
        }
        .overlay { contextMenu }
    }

    // MARK: Страницы

    private var pages: some View {
        ScrollView {
            VStack(spacing: 8) {
                ForEach(1...file.kind.pageCount, id: \.self) { number in
                    DocumentPage(kind: file.kind, number: number)
                        .background {
                            GeometryReader { geo in
                                Color.clear.preference(
                                    key: PageOffsetKey.self,
                                    value: [number: geo.frame(in: .named("doc")).minY]
                                )
                            }
                        }
                }
            }
            .padding(.top, 70)
            .padding(.bottom, 84)
            .background {
                GeometryReader { geo in
                    Color.clear.preference(
                        key: ScrollOffsetKey.self,
                        value: -geo.frame(in: .named("doc")).minY
                    )
                }
            }
        }
        .scrollIndicators(.hidden)
        .coordinateSpace(name: "doc")
        .onPreferenceChange(ScrollOffsetKey.self) { value in
            scrollOffset = max(0, value)
            pokeCounter()
        }
        .onPreferenceChange(PageOffsetKey.self) { frames in
            // Номер считается по фактическим позициям: у слайдов, листов
            // и A4 разная высота, фиксированный шаг не подходит.
            let visible = frames.filter { $0.value < 200 }.keys.max() ?? 1
            currentPage = visible
        }
    }

    // MARK: Шапка

    private var header: some View {
        HStack(spacing: 8) {
            CircleButton(systemName: "xmark") { dismiss() }
            Text(file.name)
                .font(Token.Font_.title)
                .lineLimit(1).truncationMode(.middle)
                .padding(.horizontal, 16)
                .frame(height: 44)
                .glass(.light)
            CircleButton(systemName: "ellipsis") {
                withAnimation(Token.Motion.menuPop) { menuShown = true }
            }
        }
        .padding(.horizontal, 8)
        .padding(.top, 18)
        .scaleEffect(chromeScale)
        .opacity(chromeScale)
    }

    private var counter: some View {
        Text("\(currentPage) из \(file.kind.pageCount)")
            .font(Token.Font_.footnote)
            .foregroundStyle(Token.ink)
            .padding(.horizontal, 8).padding(.vertical, 4)
            .background(.regularMaterial, in: Capsule())
            .scaleEffect(counterVisible ? 1 : 0.8, anchor: .leading)
            .opacity(counterVisible && file.kind.pageCount > 1 && chromeScale < 0.02 ? 1 : 0)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.leading, 16)
            .padding(.top, 70)
    }

    // MARK: Панель действий

    private var toolbar: some View {
        VStack {
            Spacer()
            HStack(spacing: 4) {
                toolButton("arrowshape.turn.up.forward")
                toolButton("square.and.arrow.up")
            }
            .padding(.horizontal, 4)
            .frame(height: 44)
            .glass(.light)
            .padding(.bottom, 28)
            .scaleEffect(chromeScale)
            .opacity(chromeScale)
        }
    }

    private func toolButton(_ name: String) -> some View {
        Button {} label: {
            Image(systemName: name)
                .font(.system(size: 20))
                .frame(width: 44, height: 44)
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var contextMenu: some View {
        if menuShown {
            BlobMenu(
                tone: .light,
                items: [
                    .init(title: "Показать в чате", systemImage: "eye"),
                    .init(title: "Ответить", systemImage: "arrowshape.turn.up.left"),
                    .init(title: "Печать", systemImage: "printer")
                ],
                onDismiss: { withAnimation(Token.Motion.menuHide) { menuShown = false } }
            )
            .padding(.top, 62)
            .padding(.trailing, 16)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
        }
    }

    private func pokeCounter() {
        counterTask?.cancel()
        withAnimation(.easeOut(duration: 0.25)) { counterVisible = true }
        counterTask = Task {
            try? await Task.sleep(for: .seconds(1))
            guard !Task.isCancelled else { return }
            withAnimation(.easeOut(duration: 0.25)) { counterVisible = false }
        }
    }
}

// MARK: - Ключи прокрутки

private struct ScrollOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

private struct PageOffsetKey: PreferenceKey {
    static var defaultValue: [Int: CGFloat] = [:]
    static func reduce(value: inout [Int: CGFloat], nextValue: () -> [Int: CGFloat]) {
        value.merge(nextValue()) { _, new in new }
    }
}
