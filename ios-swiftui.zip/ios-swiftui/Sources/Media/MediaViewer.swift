import SwiftUI

/// Просмотрщик фото и видео.
///
/// Экран собирается слоями: кадр, вуали, подпись, обвязка. Порядок важен —
/// подпись должна идти поверх кнопок воспроизведения, но под шапкой.
struct MediaViewer: View {
    let items: [MediaItem]
    var startIndex: Int = 0
    var caption: String?

    @Environment(\.dismiss) private var dismiss

    @State private var index: Int = 0
    @State private var chromeVisible = true
    @State private var counterVisible = false
    @State private var menuShown = false
    @State private var captionOffset: CGFloat = 0

    @StateObject private var player = PlaybackClock()
    @State private var hideTask: Task<Void, Never>?
    @State private var counterTask: Task<Void, Never>?

    private var item: MediaItem { items[index] }

    var body: some View {
        ZStack {
            Token.backdropDark.ignoresSafeArea()

            frame
            veils
            captionLayer

            if chromeVisible || player.isPlaying { playerBar }
            if chromeVisible { strip }
            topBar
            counter
        }
        .statusBarHidden(!chromeVisible)
        .overlay { contextMenu }
        .onAppear {
            index = startIndex
            player.duration = item.duration
            pokeCounter()
        }
        .onChange(of: index) { _, _ in
            player.reset(duration: item.duration)
            captionOffset = 0
            showChrome()
            pokeCounter()
        }
    }

    // MARK: Кадр

    private var frame: some View {
        GeometryReader { geo in
            // Размер считается вручную: связка aspectRatio + maxHeight
            // обрезает длинные вертикальные кадры вместо того, чтобы
            // вписывать их целиком.
            let width = min(geo.size.width, geo.size.height * item.aspect)
            let height = width / item.aspect

            Image(item.asset)
                .resizable().scaledToFill()
                .frame(width: width, height: height)
                .clipped()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .overlay {
                    // Затемнение по мере разворачивания подписи.
                    Color.black.opacity(captionDim)
                }
                .overlay {
                    if item.isVideo { playButton }
                }
                .contentShape(Rectangle())
                .onTapGesture { handleFrameTap() }
        }
        .ignoresSafeArea()
    }

    /// Кнопка воспроизведения лежит ниже текста: поднятая подпись должна
    /// проходить поверх неё.
    private var playButton: some View {
        Button {
            player.toggle()
            if player.isPlaying { armHide(after: Token.Motion.hideAfterPlay) }
            else { showChrome() }
        } label: {
            Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                .font(.system(size: 26))
                .frame(width: 72, height: 72)
                .glass(.dark, shape: Circle())
                .contentTransition(.symbolEffect(.replace.downUp))
        }
        .buttonStyle(.plain)
        .opacity(chromeVisible ? 1 : 0)
        .zIndex(1)
    }

    private var captionDim: Double { min(0.65, Double(captionOffset) / 500 * 0.65) }

    // MARK: Вуали

    private var veils: some View {
        VStack {
            LinearGradient(
                stops: [
                    .init(color: .black.opacity(0.50), location: 0),
                    .init(color: .black.opacity(0.34), location: 0.32),
                    .init(color: .clear, location: 1)
                ], startPoint: .top, endPoint: .bottom
            )
            .frame(height: 200)
            Spacer()
            LinearGradient(
                stops: [
                    .init(color: .black.opacity(0.78), location: 0),
                    .init(color: .black.opacity(0.62), location: 0.26),
                    .init(color: .black.opacity(0.34), location: 0.58),
                    .init(color: .clear, location: 1)
                ], startPoint: .bottom, endPoint: .top
            )
            .frame(height: 300)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .opacity(chromeVisible ? 1 : 0)
    }

    // MARK: Подпись

    @ViewBuilder
    private var captionLayer: some View {
        if let caption, !caption.isEmpty {
            CaptionScroll(text: caption, offset: $captionOffset) {
                // Касание подписи останавливает автоскрытие: иначе на
                // видео таймер срабатывал посреди жеста.
                showChrome()
            } onRelease: {
                if player.isPlaying, captionOffset <= 0 {
                    armHide(after: Token.Motion.hideAfterTap)
                }
            }
            .opacity(chromeVisible ? 1 : 0)
            .zIndex(2)
        }
    }

    // MARK: Обвязка

    private var topBar: some View {
        VStack {
            HStack(spacing: 12) {
                CircleButton(systemName: "chevron.backward", tone: .dark) { dismiss() }
                VStack(spacing: 0) {
                    Text("Иван Петров").font(Token.Font_.title)
                    Text("Сегодня, 9:41")
                        .font(Token.Font_.footnote)
                        .foregroundStyle(.white.opacity(0.62))
                }
                .padding(.horizontal, 16)
                .frame(height: 44)
                .glass(.dark)
                CircleButton(systemName: "ellipsis", tone: .dark) {
                    withAnimation(Token.Motion.menuPop) { menuShown = true }
                }
            }
            .padding(.horizontal, 16)
            Spacer()
        }
        .padding(.top, 8)
        .offset(y: chromeVisible ? 0 : -120)
        .opacity(chromeVisible ? 1 : 0)
        .zIndex(5)
    }

    private var counter: some View {
        VStack {
            Text("\(index + 1) из \(items.count)")
                .font(Token.Font_.footnote)
                .foregroundStyle(.white)
                .padding(.horizontal, 8).padding(.vertical, 4)
                .background(.black.opacity(0.32), in: Capsule())
                .scaleEffect(counterVisible ? 1 : 0.8)
                .opacity(counterVisible && chromeVisible && items.count > 1 ? 1 : 0)
            Spacer()
        }
        .padding(.top, 58)
        .allowsHitTesting(false)
    }

    private var playerBar: some View {
        VStack {
            Spacer()
            PlayerBar(clock: player, compact: !chromeVisible)
                .padding(.horizontal, chromeVisible ? 28 : 28)
                .padding(.bottom, chromeVisible ? 138 : 50)
        }
        .opacity(item.isVideo ? 1 : 0)
        .zIndex(5)
    }

    private var strip: some View {
        VStack {
            Spacer()
            VStack(spacing: 0) {
                ThumbnailStrip(items: items, selection: $index)
                actionRow
            }
        }
        .offset(y: chromeVisible ? 0 : 140)
        .opacity(chromeVisible ? 1 : 0)
        .zIndex(5)
    }

    private var actionRow: some View {
        HStack {
            ForEach(["arrowshape.turn.up.forward",
                     item.isVideo ? "timer" : "square.and.arrow.up",
                     "arrow.down.to.line"], id: \.self) { name in
                Button {} label: {
                    Image(systemName: name)
                        .font(.system(size: 20))
                        .frame(width: 44, height: 44)
                        .glass(.dark, shape: Circle())
                }
                .buttonStyle(.plain)
                if name != "arrow.down.to.line" { Spacer() }
            }
        }
        .padding(.horizontal, 28)
        .padding(.top, 8)
        .padding(.bottom, 30)
    }

    // MARK: Меню

    @ViewBuilder
    private var contextMenu: some View {
        if menuShown {
            BlobMenu(
                tone: .dark,
                items: [
                    .init(title: "Показать в чате", systemImage: "eye"),
                    .init(title: "Ответить", systemImage: "arrowshape.turn.up.left"),
                    .init(title: "Свернуть", systemImage: "arrow.down.right.and.arrow.up.left",
                          disabled: !item.isVideo),
                    .init(title: "Удалить", systemImage: "trash")
                ],
                onDismiss: { withAnimation(Token.Motion.menuHide) { menuShown = false } }
            )
            .padding(.top, 106)
            .padding(.trailing, 16)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
        }
    }

    // MARK: Обвязка — логика

    private func handleFrameTap() {
        if item.isVideo {
            if !chromeVisible {
                showChrome()
                if player.isPlaying { armHide(after: Token.Motion.hideAfterTap) }
            }
        } else {
            // У фото тап работает переключателем: можно смотреть снимок
            // без обвязки и вернуть её тем же жестом.
            if chromeVisible, captionOffset <= 0 {
                withAnimation(Token.Motion.chromeOut) { chromeVisible = false }
            } else {
                showChrome()
            }
        }
    }

    private func showChrome() {
        hideTask?.cancel()
        withAnimation(Token.Motion.chromeIn) { chromeVisible = true }
    }

    private func armHide(after delay: TimeInterval) {
        hideTask?.cancel()
        hideTask = Task {
            try? await Task.sleep(for: .seconds(delay))
            guard !Task.isCancelled, player.isPlaying, !menuShown, captionOffset <= 0 else { return }
            withAnimation(Token.Motion.chromeOut) { chromeVisible = false }
        }
    }

    private func pokeCounter() {
        guard items.count > 1 else { return }
        counterTask?.cancel()
        withAnimation(.easeOut(duration: 0.25)) { counterVisible = true }
        counterTask = Task {
            try? await Task.sleep(for: .seconds(Token.Motion.counterLifetime))
            guard !Task.isCancelled else { return }
            withAnimation(.easeOut(duration: 0.25)) { counterVisible = false }
        }
    }
}
