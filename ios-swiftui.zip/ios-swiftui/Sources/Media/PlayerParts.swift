import SwiftUI
import Combine

// MARK: - Часы воспроизведения

/// Имитация плеера: в проекте на её место встаёт `AVPlayer`, интерфейс
/// остаётся тем же — `progress`, `isPlaying`, `toggle()`.
@MainActor
final class PlaybackClock: ObservableObject {
    @Published private(set) var time: TimeInterval = 0
    @Published private(set) var isPlaying = false
    var duration: TimeInterval = 42

    private var timer: AnyCancellable?

    var progress: Double { duration > 0 ? time / duration : 0 }

    func toggle() { isPlaying ? pause() : play() }

    func play() {
        isPlaying = true
        timer = Timer.publish(every: 0.1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                guard let self else { return }
                time += 0.1
                if time >= duration { time = 0 }   // ролик идёт по кругу
            }
    }

    func pause() {
        isPlaying = false
        timer?.cancel(); timer = nil
    }

    func reset(duration: TimeInterval) {
        pause()
        self.duration = duration
        time = 0
    }

    func seek(to fraction: Double) {
        time = max(0, min(duration, duration * fraction))
    }

    static func format(_ seconds: TimeInterval) -> String {
        let s = Int(seconds.rounded())
        return String(format: "%d:%02d", s / 60, s % 60)
    }
}

// MARK: - Пилюля плеера

struct PlayerBar: View {
    @ObservedObject var clock: PlaybackClock
    /// В режиме просмотра пилюля превращается в тонкий индикатор.
    var compact: Bool

    var body: some View {
        Group {
            if compact {
                track(height: 6, showLabels: false)
            } else {
                HStack(spacing: 10) {
                    Text(PlaybackClock.format(clock.time))
                    track(height: 6, showLabels: true)
                    Text(PlaybackClock.format(clock.duration))
                }
                .font(Token.Font_.footnote)
                .monospacedDigit()
                .foregroundStyle(.white)
                .padding(.horizontal, 12)
                .frame(height: 44)
                .glass(.dark)
            }
        }
        .animation(Token.Motion.chromeIn, value: compact)
    }

    private func track(height: CGFloat, showLabels: Bool) -> some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(showLabels ? 0.24 : 0))
                Capsule()
                    .fill(showLabels ? Color.white : Color(hex: 0x777675))
                    .frame(width: geo.size.width * clock.progress)
            }
            .contentShape(Rectangle())
            .onTapGesture { location in
                clock.seek(to: location.x / geo.size.width)
            }
        }
        .frame(height: height)
    }
}

// MARK: - Лента миниатюр

/// Механика как в Telegram: невыбранные кадры узкие, выбранный
/// раскрывается по своим пропорциям. Вся лента умещается в кадр без
/// прокрутки — если широкий выбранный не влезает, остальные ужимаются.
struct ThumbnailStrip: View {
    let items: [MediaItem]
    @Binding var selection: Int

    private let height: CGFloat = 36
    private let gap: CGFloat = 4
    private let frameInset: CGFloat = 24
    private let narrowDefault: CGFloat = 20

    var body: some View {
        GeometryReader { geo in
            let available = geo.size.width - frameInset * 2
            let activeWidth = (height * items[selection].aspect).rounded()
            let fit = items.count > 1
                ? ((available - gap * CGFloat(items.count - 1) - activeWidth) / CGFloat(items.count - 1)).rounded(.down)
                : narrowDefault
            let narrow = max(10, min(narrowDefault, fit))

            HStack(spacing: gap) {
                ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
                    Image(item.asset)
                        .resizable().scaledToFill()
                        .frame(width: index == selection ? activeWidth : narrow, height: height)
                        .clipShape(RoundedRectangle(cornerRadius: 5, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 5, style: .continuous)
                                .fill(.black.opacity(index == selection ? 0 : 0.4))
                        }
                        .onTapGesture {
                            withAnimation(Token.Motion.thumb) { selection = index }
                        }
                }
            }
            .frame(maxWidth: .infinity)
        }
        .frame(height: height)
        .padding(.top, 8)
        .padding(.bottom, 4)
    }
}

// MARK: - Подпись

/// Подпись прижата к низу распоркой и разворачивается прокруткой вверх.
struct CaptionScroll: View {
    let text: String
    @Binding var offset: CGFloat
    var onTouch: () -> Void
    var onRelease: () -> Void

    var body: some View {
        GeometryReader { geo in
            ScrollView {
                VStack(spacing: 0) {
                    // Распорка задаёт, сколько текста видно в покое.
                    Color.clear.frame(height: max(0, geo.size.height - 208))
                    Text(text)
                        .font(Token.Font_.body)
                        .foregroundStyle(.white)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 210)
                        .background {
                            GeometryReader { inner in
                                Color.clear.preference(
                                    key: CaptionOffsetKey.self,
                                    value: -inner.frame(in: .named("caption")).minY
                                )
                            }
                        }
                }
            }
            .scrollIndicators(.hidden)
            .coordinateSpace(name: "caption")
            .onPreferenceChange(CaptionOffsetKey.self) { offset = max(0, $0) }
            .mask {
                // Снизу текст растворяется, а не обрывается линией.
                LinearGradient(
                    stops: [
                        .init(color: .black, location: 0),
                        .init(color: .black, location: 0.82),
                        .init(color: .black.opacity(0.4), location: 0.94),
                        .init(color: .clear, location: 1)
                    ], startPoint: .top, endPoint: .bottom
                )
            }
            .simultaneousGesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in onTouch() }
                    .onEnded { _ in onRelease() }
            )
        }
        .ignoresSafeArea()
    }
}

private struct CaptionOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
