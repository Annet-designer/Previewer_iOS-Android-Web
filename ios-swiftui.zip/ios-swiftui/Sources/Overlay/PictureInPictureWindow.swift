import SwiftUI

/// Мини-экран поверх чата.
///
/// В продакшене видео в PiP отдаётся системе через `AVPictureInPicture`,
/// и окно рисует сама iOS. Здесь окно своё — оно живёт внутри приложения,
/// зато полностью управляемо.
struct PictureInPictureWindow: View {
    let item: MediaItem
    @ObservedObject var clock: PlaybackClock
    var onExpand: () -> Void
    var onClose: () -> Void

    @State private var origin: CGPoint = .zero
    @State private var dragOffset: CGSize = .zero
    @State private var controlsVisible = true
    @State private var hideTask: Task<Void, Never>?

    private let baseWidth: CGFloat = 150
    private let edgeX: CGFloat = 10
    private let edgeTop: CGFloat = 56
    private let edgeBottom: CGFloat = 40

    var body: some View {
        GeometryReader { geo in
            let width = min(geo.size.width - edgeX * 2, max(baseWidth, baseWidth * item.aspect))
            let height = width / item.aspect

            content(width: width, height: height)
                .position(
                    x: origin.x + dragOffset.width + width / 2,
                    y: origin.y + dragOffset.height + height / 2
                )
                .gesture(drag(in: geo.size, size: CGSize(width: width, height: height)))
                .onAppear {
                    origin = CGPoint(x: geo.size.width - width - edgeX, y: 128)
                    pokeControls()
                }
        }
        .ignoresSafeArea()
    }

    private func content(width: CGFloat, height: CGFloat) -> some View {
        Image(item.asset)
            .resizable().scaledToFill()
            .frame(width: width, height: height)
            .clipShape(RoundedRectangle(cornerRadius: Token.Radius.pip, style: .continuous))
            .overlay(alignment: .topLeading) { roundButton("xmark", action: onClose).padding(6) }
            .overlay(alignment: .topTrailing) {
                roundButton("arrow.up.left.and.arrow.down.right", action: onExpand).padding(6)
            }
            .overlay { if item.isVideo { playControls } }
            .overlay(alignment: .bottom) { if item.isVideo { progress } }
            .shadow(color: Token.Shadow.pip.color, radius: Token.Shadow.pip.radius, y: Token.Shadow.pip.y)
            .onTapGesture {
                // При скрытых кнопках первый тап возвращает их, а не
                // разворачивает окно.
                if controlsVisible { onExpand() } else { pokeControls() }
            }
    }

    private var playControls: some View {
        HStack(spacing: 10) {
            roundButton("gobackward.10", size: 32) { clock.seek(to: max(0, clock.progress - 10 / clock.duration)) }
            roundButton(clock.isPlaying ? "pause.fill" : "play.fill", size: 46) { clock.toggle() }
            roundButton("goforward.10", size: 32) { clock.seek(to: min(1, clock.progress + 10 / clock.duration)) }
        }
        .opacity(controlsVisible ? 1 : 0)
        .animation(.easeOut(duration: 0.22), value: controlsVisible)
    }

    private var progress: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(0.3))
                Capsule().fill(.white).frame(width: geo.size.width * clock.progress)
            }
        }
        .frame(height: 4)
        .padding(8)
        .opacity(controlsVisible ? 1 : 0)
        .animation(.easeOut(duration: 0.22), value: controlsVisible)
    }

    private func roundButton(_ name: String, size: CGFloat = 28, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: name)
                .font(.system(size: size * 0.45))
                .foregroundStyle(.white)
                .frame(width: size, height: size)
                .background(.black.opacity(0.44), in: Circle())
        }
        .buttonStyle(.plain)
        .opacity(controlsVisible ? 1 : 0)
        .animation(.easeOut(duration: 0.22), value: controlsVisible)
    }

    // MARK: Перетаскивание

    private func drag(in bounds: CGSize, size: CGSize) -> some Gesture {
        DragGesture()
            .onChanged { value in
                dragOffset = value.translation
                pokeControls()
            }
            .onEnded { _ in
                let x = origin.x + dragOffset.width
                let y = origin.y + dragOffset.height
                // Примагничивание к ближайшему из четырёх углов.
                let snapX = (x + size.width / 2) < bounds.width / 2
                    ? edgeX : bounds.width - size.width - edgeX
                let snapY = (y + size.height / 2) < bounds.height / 2
                    ? edgeTop : bounds.height - size.height - edgeBottom
                dragOffset = .zero
                withAnimation(Token.Motion.pipSnap) {
                    origin = CGPoint(x: snapX, y: snapY)
                }
            }
    }

    private func pokeControls() {
        hideTask?.cancel()
        controlsVisible = true
        hideTask = Task {
            try? await Task.sleep(for: .seconds(2))
            guard !Task.isCancelled else { return }
            controlsVisible = false
        }
    }
}
