import SwiftUI

/// Контекстное меню, вырастающее каплей.
///
/// В мокапе анимировались ширина, высота и радиус: кружок 34×34 раздувался
/// до полного размера, скругление ехало с 50% к 32. В SwiftUI то же
/// достигается масштабированием с якорем в углу — дешевле по отрисовке и
/// не заставляет пересчитывать раскладку каждый кадр.
struct BlobMenu: View {
    struct Item: Identifiable {
        let id = UUID()
        let title: String
        let systemImage: String
        var disabled: Bool = false
        var action: () -> Void = {}
    }

    var tone: GlassBackground.Tone = .dark
    var items: [Item]
    var onDismiss: () -> Void

    @State private var shown = false

    var body: some View {
        ZStack(alignment: .topTrailing) {
            // Прозрачная подложка: ловит нажатие мимо меню и не затемняет
            // экран — затемнение здесь только мешало смотреть кадр.
            Color.clear
                .contentShape(Rectangle())
                .ignoresSafeArea()
                .onTapGesture { onDismiss() }

            VStack(spacing: 0) {
                ForEach(items) { item in
                    Button {
                        item.action(); onDismiss()
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: item.systemImage)
                                .font(.system(size: 17))
                                .frame(width: 24, height: 24)
                            Text(item.title).font(Token.Font_.menuItem)
                            Spacer(minLength: 0)
                        }
                        .padding(.horizontal, 10)
                        .frame(height: 40)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .disabled(item.disabled)
                    .opacity(item.disabled ? 0.4 : 1)
                }
            }
            .padding(10)
            .frame(width: 238)
            .glass(tone, shape: RoundedRectangle(cornerRadius: Token.Radius.menu, style: .continuous))
            .shadow(color: Token.Shadow.menu.color,
                    radius: Token.Shadow.menu.radius,
                    y: Token.Shadow.menu.y)
            // Якорь в правом верхнем углу: капля растёт от кнопки внутрь
            // экрана, а не разъезжается в обе стороны.
            .scaleEffect(shown ? 1 : 0.72, anchor: .topTrailing)
            .opacity(shown ? 1 : 0)
        }
        .onAppear {
            withAnimation(Token.Motion.menuPop) { shown = true }
        }
    }
}
