import SwiftUI

/// Содержимое чата один в один с мокапом — чтобы можно было сверять
/// экран с макетом, не подставляя свои данные.
enum SampleData {

    static let files: [DocumentFile] = [
        .init(name: "Дизайн-концепция_сайта.docx", kind: .docx, size: "48 Кб"),
        .init(name: "Гайдлайн_бренда.pdf",          kind: .pdf,  size: "2,4 Мб"),
        .init(name: "Редизайн_сайта.pptx",          kind: .pptx, size: "6,1 Мб"),
        .init(name: "Отчет_Q3_2026.xlsx",           kind: .xlsx, size: "310 Кб"),
        .init(name: "index.html",                   kind: .html, size: "12 Кб"),
        .init(name: "README.md",                    kind: .md,   size: "4 Кб"),
        .init(name: "notes.txt",                    kind: .txt,  size: "2 Кб")
    ]

    /// Галерея из четырёх кадров с длинной подписью.
    static let gallery: [MediaItem] = [
        .init("gallery-1-office",         aspect: 634 / 697),
        .init("gallery-2-server-video",   aspect: 634 / 697, isVideo: true),
        .init("gallery-3-robot",          aspect: 640 / 274),
        .init("gallery-4-headphones",     aspect: 440 / 954)
    ]

    /// Мозаика из десяти снимков без подписи.
    static let mosaic: [MediaItem] = [
        .init("mosaic-01", aspect: 1200 / 2400),
        .init("mosaic-02", aspect:  720 / 1280, isVideo: true),
        .init("mosaic-03", aspect:  720 / 1280),
        .init("mosaic-04", aspect: 1200 / 1200),
        .init("mosaic-05", aspect:  634 /  697),
        .init("mosaic-06", aspect: 1024 / 1024),
        .init("mosaic-07", aspect:  714 / 1280),
        .init("mosaic-08", aspect:  634 /  697),
        .init("mosaic-09", aspect:  540 /  360),
        .init("mosaic-10", aspect:  703 /  481)
    ]

    static let singleVideo = MediaItem("mosaic-10", aspect: 703 / 481, isVideo: true, duration: 10)
    static let singlePhoto = MediaItem("single-dunes", aspect: 572 / 335)

    static let caption = """
        Первые наброски главной — герой со скриншотом интерфейса вместо \
        абстракции и два референса по настроению. На первом кадре то, к чему \
        пришли после трёх итераций: заголовок в две строки, под ним одно \
        предложение и две кнопки, справа живой экран продукта, а не картинка \
        про технологии. Второй — короткая анимация того же блока, видно, как \
        он собирается по шагам и где мы теряем секунду на загрузке. Нижние \
        два кадра про свет и материал: холодный тех и предметная съёмка на \
        сером. Смотреть лучше подряд, они про одно и то же, просто с разных \
        сторон. Какое направление ближе? По первому кадру: заголовок набран \
        в две строки не от красоты, а потому что в одну он на 390 не \
        помещается без переноса посреди слова. Кнопки поставил рядом, а не \
        одну под другой — так вторая не выглядит отказом от первой. Про \
        анимацию: она держится ровно секунду, дольше не имеет смысла, \
        человек уже проскроллил. Собирается снизу вверх, последним приезжает \
        экран продукта — на нём и хочется остановить внимание. Свет на \
        третьем кадре холодный и контрастный, на четвёртом мягкий и \
        рассеянный; по отдельности оба работают, вместе на одной странице \
        спорят. Если берём холодный, придётся переснимать предметку — это \
        ещё неделя и отдельный бюджет на студию. Если мягкий, переделываем \
        герой: там сейчас всё держится на контрасте, и в рассеянном свете он \
        рассыплется. Поэтому и спрашиваю до того, как ушли в макеты. \
        Переснять проще, чем потом объяснять, почему главная и блог выглядят \
        из разных проектов.
        """

    static let messages: [Message] = [
        .init(isOutgoing: false, time: "9:41", content: .text("""
            Прошёлся по слайдам и оставил комментарии в разделе «замечания». \
            Ниже коротко главное, чтобы не искать по документу.
            """), width: 341),
        .init(isOutgoing: true, time: "9:41",
              content: .text("Ок, посмотрю к вечеру")),
        .init(isOutgoing: false, time: "9:41",
              content: .files(files), width: 341),
        .init(isOutgoing: false, time: "9:41",
              content: .text("Привет! Из нашей переписки в почте")),
        .init(isOutgoing: false, time: "9:41",
              content: .gallery(items: gallery, layout: .grid2, caption: caption), width: 341),
        .init(isOutgoing: false, time: "9:41",
              content: .gallery(items: mosaic, layout: .mosaic, caption: nil), width: 341),
        .init(isOutgoing: false, time: "9:41",
              content: .gallery(items: [singleVideo], layout: .single, caption: nil), width: 341),
        .init(isOutgoing: true, time: "9:41",
              content: .gallery(items: [singlePhoto], layout: .single, caption: nil), width: 341)
    ]
}
