import SwiftUI

// MARK: - Медиа

struct MediaItem: Identifiable, Hashable {
    let id = UUID()
    /// Имя ассета в каталоге.
    let asset: String
    /// Пропорции кадра. В мокапе жили в `data-ar`.
    let aspect: CGFloat
    /// Видео или снимок.
    let isVideo: Bool
    /// Хронометраж в секундах. В мокапе — `data-dur`.
    let duration: TimeInterval

    init(_ asset: String, aspect: CGFloat, isVideo: Bool = false, duration: TimeInterval = 42) {
        self.asset = asset
        self.aspect = aspect
        self.isVideo = isVideo
        self.duration = duration
    }
}

// MARK: - Документ

struct DocumentFile: Identifiable, Hashable {
    enum Kind: String {
        case docx, pdf, pptx, xlsx, html, md, txt

        /// Подпись на иконке файла.
        var badge: String { rawValue }

        /// Сколько страниц показывает превьюер.
        var pageCount: Int {
            switch self {
            case .docx: 3
            case .pdf:  5
            case .pptx: 4
            case .xlsx: 2
            case .html: 2
            case .md, .txt: 1
            }
        }

        /// Пропорции листа: A4, слайд 16:9 или свободная высота.
        var pageAspect: CGFloat? {
            switch self {
            case .docx, .pdf: 393.0 / 546.0
            case .pptx: 16.0 / 9.0
            default: nil
            }
        }
    }

    let id = UUID()
    let name: String
    let kind: Kind
    let size: String
}

// MARK: - Сообщение

struct Message: Identifiable {
    enum Content {
        case text(String)
        /// Плашки файлов одним пузырём.
        case files([DocumentFile])
        /// Галерея с подписью под ней.
        case gallery(items: [MediaItem], layout: GalleryLayout, caption: String?)
    }

    enum GalleryLayout {
        /// Сетка 2×2, скругление только сверху — снизу подпись.
        case grid2
        /// Мозаика 2/3/2/3 с рядами разной высоты.
        case mosaic
        /// Один кадр во всю ширину пузыря.
        case single
    }

    let id = UUID()
    let isOutgoing: Bool
    let time: String
    let content: Content
    /// Ширина пузыря из макета. nil — по содержимому.
    var width: CGFloat?
}
